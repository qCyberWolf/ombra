import time
import json
import threading
import socket
from typing import List, Dict, Any, Optional
import random
import sys
import os

# Add parent directory to sys.path for absolute imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Replace relative imports with absolute imports
from core.blockchain import OmbraBlockchain
from core.transaction import Transaction
from network.p2p import P2PNetwork

class OmbraNode:
    """
    Node implementation for the Ombra blockchain network.
    Manages the blockchain, transaction processing, and P2P communication.
    """
    
    def __init__(self, host: str, port: int):
        self.blockchain = OmbraBlockchain()
        self.node_id = self.blockchain.node_id
        self.network = P2PNetwork(host, port, self.node_id)
        self.syncing = False
        self.running = False
        self._setup_message_handlers()
        
    def start(self) -> None:
        """Start the blockchain node"""
        # Initialize genesis transaction if needed
        if self.blockchain.ledger.transaction_count == 0:
            self.blockchain.create_genesis_transaction()
            
        # Start P2P network
        self.network.start()
        self.running = True
        
        # Start main node processing loop
        self._processing_thread = threading.Thread(target=self._process_loop, daemon=True)
        self._processing_thread.start()
        
        print(f"Ombra node {self.node_id} started successfully")
        
    def stop(self) -> None:
        """Stop the blockchain node"""
        self.running = False
        self.network.stop()
        print(f"Ombra node {self.node_id} stopped")
        
    def connect_to_network(self, seed_host: str, seed_port: int) -> bool:
        """Connect to the network via a seed node"""
        return self.network.connect_to_peer(seed_host, seed_port)
        
    def add_transaction(self, transaction: Transaction) -> bool:
        """Add a transaction to the blockchain"""
        if self.blockchain.add_transaction(transaction):
            # Broadcast transaction to network
            self.network.broadcast_message({
                'type': 'new_transaction',
                'transaction': transaction.to_dict(),
                'sender_node': self.node_id
            })
            return True
        return False
        
    def _setup_message_handlers(self) -> None:
        """Set up handlers for different message types"""
        self.network.register_handler('new_transaction', self._handle_new_transaction)
        self.network.register_handler('sync_request', self._handle_sync_request)
        self.network.register_handler('sync_response', self._handle_sync_response)
        
    def _handle_new_transaction(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Handle incoming new transaction message"""
        try:
            tx_data = message.get('transaction', {})
            sender_node = message.get('sender_node', '')
            
            # Skip if we're the original sender
            if sender_node == self.node_id:
                return {'status': 'ignored', 'reason': 'own_transaction'}
            
            # Convert dict to Transaction object
            transaction = Transaction.from_dict(tx_data)
            
            # Add to blockchain (if valid)
            if self.blockchain.add_transaction(transaction):
                return {'status': 'accepted'}
            else:
                return {'status': 'rejected', 'reason': 'invalid_transaction'}
                
        except Exception as e:
            print(f"Error handling transaction: {str(e)}")
            return {'status': 'error', 'reason': str(e)}
            
    def _handle_sync_request(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Handle incoming sync request"""
        last_known_tx = message.get('last_tx_hash', '')
        requester_node_id = message.get('node_id', '')
        
        # Gather transactions to send
        transactions_to_sync = []
        
        # If the node has no transactions, send everything
        if not last_known_tx:
            # Limit to latest 50 transactions to avoid huge messages
            for layer_id in sorted(self.blockchain.ledger.layers.keys(), reverse=True):
                for tx_hash in self.blockchain.ledger.layers[layer_id]:
                    tx = self.blockchain.ledger.transactions[tx_hash]
                    transactions_to_sync.append(tx.to_dict())
                    if len(transactions_to_sync) >= 50:
                        break
                if len(transactions_to_sync) >= 50:
                    break
        else:
            # Start syncing from the last known transaction
            found_last_tx = False
            for layer_id in sorted(self.blockchain.ledger.layers.keys()):
                tx_hashes = self.blockchain.ledger.layers[layer_id]
                for tx_hash in tx_hashes:
                    if found_last_tx:
                        tx = self.blockchain.ledger.transactions[tx_hash]
                        transactions_to_sync.append(tx.to_dict())
                    elif tx_hash == last_known_tx:
                        found_last_tx = True
        
        return {
            'status': 'ok',
            'transactions': transactions_to_sync,
            'node_id': self.node_id
        }
        
    def _handle_sync_response(self, message: Dict[str, Any]) -> None:
        """Handle sync response with new transactions"""
        if message.get('status') != 'ok':
            return
            
        transactions = message.get('transactions', [])
        sender_node_id = message.get('node_id', '')
        
        # Process transactions in order
        for tx_data in transactions:
            transaction = Transaction.from_dict(tx_data)
            self.blockchain.add_transaction(transaction)
            
        print(f"Synced {len(transactions)} transactions from node {sender_node_id}")
        self.syncing = False
        
    def _process_loop(self) -> None:
        """Main processing loop for the node"""
        while self.running:
            # Process pending transactions
            if self.blockchain.pending_transactions:
                processed = self.blockchain.process_pending_transactions()
                if processed:
                    print(f"Processed {len(processed)} transactions")
            
            # Sync with peers periodically
            if not self.syncing and random.random() < 0.1:  # 10% chance each cycle
                self._request_sync_from_random_peer()
                
            # Sleep to avoid CPU hogging
            time.sleep(1)
            
    def _request_sync_from_random_peer(self) -> None:
        """Request sync from a random peer"""
        if not self.network.peers:
            return
            
        self.syncing = True
        
        # Select random peer
        peer_id = random.choice(list(self.network.peers.keys()))
        peer_host, peer_port = self.network.peers[peer_id]
        
        # Find last transaction hash (from highest layer)
        last_tx_hash = ""
        if self.blockchain.ledger.layers:
            highest_layer = max(self.blockchain.ledger.layers.keys())
            if self.blockchain.ledger.layers[highest_layer]:
                last_tx_hash = self.blockchain.ledger.layers[highest_layer][0]
        
        # Send sync request
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)
            s.connect((peer_host, peer_port))
            
            sync_request = {
                'type': 'sync_request',
                'node_id': self.node_id,
                'last_tx_hash': last_tx_hash
            }
            
            s.send(json.dumps(sync_request).encode('utf-8'))
            
            # Response will be handled by the message handlers
            s.close()
            
        except Exception as e:
            print(f"Failed to request sync from {peer_id}: {str(e)}")
            self.syncing = False
            # Remove dead peer
            if peer_id in self.network.peers:
                del self.network.peers[peer_id]
