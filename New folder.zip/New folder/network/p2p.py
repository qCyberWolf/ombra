import socket
import threading
import json
import time
import random
from typing import List, Dict, Any, Callable, Optional

class P2PNetwork:
    """
    Peer-to-peer network implementation for Ombra blockchain.
    Handles node discovery, message broadcasting, and transaction propagation.
    """
    
    def __init__(self, host: str, port: int, node_id: str):
        self.host = host
        self.port = port
        self.node_id = node_id
        self.peers = {}  # {node_id: (host, port)}
        self.server_socket = None
        self.running = False
        self.message_handlers = {}
        
    def start(self) -> None:
        """Start the P2P server"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            # Try to get the local IP for better diagnostics
            local_ip = "Unknown"
            try:
                temp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                temp_socket.connect(("8.8.8.8", 80))
                local_ip = temp_socket.getsockname()[0]
                temp_socket.close()
            except:
                pass
                
            # Provide more diagnostic info before binding
            print(f"Attempting to bind to {self.host}:{self.port}")
            print(f"System reports local IP as: {local_ip}")
            
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(10)
            self.running = True
            
            if self.host == "0.0.0.0":
                print(f"P2P server started and listening on all interfaces (port {self.port})")
                print(f"Other nodes can connect to this node at {local_ip}:{self.port}")
            else:
                print(f"P2P server started on {self.host}:{self.port}")
            
            # Start listening for incoming connections
            threading.Thread(target=self._listen_for_connections, daemon=True).start()
        except Exception as e:
            print(f"Failed to start P2P network: {str(e)}")
            print(f"NETWORK BINDING TROUBLESHOOTING:")
            print(f"1. If using specific IP: Check if {self.host} exists on this machine")
            print(f"2. Try using '0.0.0.0' to bind to all interfaces")
            print(f"3. Check if port {self.port} is already in use by another application")
            self.running = False
            
    def stop(self) -> None:
        """Stop the P2P server"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
            
    def _listen_for_connections(self) -> None:
        """Listen for incoming connections"""
        while self.running:
            try:
                client_socket, client_addr = self.server_socket.accept()
                threading.Thread(target=self._handle_connection, 
                              args=(client_socket,), daemon=True).start()
            except Exception as e:
                if self.running:
                    print(f"Connection error: {str(e)}")
                    
    def _handle_connection(self, client_socket: socket.socket) -> None:
        """Handle incoming connection and messages"""
        try:
            # Read message from client
            data = client_socket.recv(4096)
            if not data:
                return
                
            # Parse message
            message = json.loads(data.decode('utf-8'))
            message_type = message.get('type')
            
            # Handle different message types
            if message_type in self.message_handlers:
                response = self.message_handlers[message_type](message)
                
                # Send response if needed
                if response:
                    client_socket.send(json.dumps(response).encode('utf-8'))
                    
            elif message_type == 'handshake':
                # Handle peer discovery
                peer_id = message.get('node_id')
                peer_host = message.get('host')
                peer_port = message.get('port')
                
                if peer_id and peer_id != self.node_id:
                    self.peers[peer_id] = (peer_host, peer_port)
                    print(f"New peer connected: {peer_id} at {peer_host}:{peer_port}")
                    
                # Send our peer list for network discovery
                client_socket.send(json.dumps({
                    'type': 'peer_list',
                    'peers': {id: {'host': host, 'port': port} 
                             for id, (host, port) in self.peers.items()}
                }).encode('utf-8'))
                
        except Exception as e:
            print(f"Error handling connection: {str(e)}")
        finally:
            client_socket.close()
            
    def register_handler(self, message_type: str, handler: Callable) -> None:
        """Register a handler for a specific message type"""
        self.message_handlers[message_type] = handler
        
    def connect_to_peer(self, host: str, port: int) -> bool:
        """Connect to a peer node"""
        try:
            print(f"Attempting to connect to peer at {host}:{port}...")
            
            # Try to resolve hostname to check if it's valid
            try:
                socket.gethostbyname(host)
            except socket.gaierror:
                print(f"Warning: Could not resolve hostname '{host}'. Check if this is a valid address.")
            
            # Create socket connection
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)  # 5 second timeout
            s.connect((host, port))
            
            # Send handshake message
            handshake = {
                'type': 'handshake',
                'node_id': self.node_id,
                'host': self.host,
                'port': self.port,
                'timestamp': time.time()
            }
            
            s.send(json.dumps(handshake).encode('utf-8'))
            
            # Wait for response
            response = s.recv(4096)
            response_data = json.loads(response.decode('utf-8'))
            
            # Process peer list if provided
            if response_data.get('type') == 'peer_list':
                for peer_id, peer_info in response_data.get('peers', {}).items():
                    if peer_id != self.node_id and peer_id not in self.peers:
                        self.peers[peer_id] = (peer_info['host'], peer_info['port'])
                        
            print(f"Successfully connected to peer at {host}:{port}")
            s.close()
            return True
            
        except Exception as e:
            print(f"Failed to connect to peer {host}:{port}: {str(e)}")
            # Provide helpful troubleshooting
            if "getaddrinfo failed" in str(e):
                print(f"  → The hostname '{host}' could not be resolved. Use a valid IP address or hostname.")
            elif "timeout" in str(e):
                print(f"  → Connection timed out. Check if peer is running and network allows connections.")
            elif "refused" in str(e):
                print(f"  → Connection refused. Check if peer is running and accepting connections on port {port}.")
            return False
            
    def broadcast_message(self, message: Dict[str, Any]) -> None:
        """Broadcast a message to all peers"""
        message_json = json.dumps(message).encode('utf-8')
        
        for peer_id, (host, port) in list(self.peers.items()):
            threading.Thread(target=self._send_to_peer, 
                          args=(host, port, message_json, peer_id),
                          daemon=True).start()
                          
    def _send_to_peer(self, host: str, port: int, message_json: bytes, peer_id: str) -> None:
        """Send a message to a specific peer"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)
            s.connect((host, port))
            s.send(message_json)
            s.close()
        except Exception as e:
            print(f"Failed to send to peer {peer_id}: {str(e)}")
            # Remove dead peer
            if peer_id in self.peers:
                del self.peers[peer_id]
