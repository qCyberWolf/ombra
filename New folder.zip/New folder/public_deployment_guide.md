# Ombra Blockchain - Public Deployment Guide

This guide will help you deploy your Ombra blockchain node and API to make them publicly accessible on the internet.

## Prerequisites

1. A server with a public IP address or domain name
2. Administrative access to your router (for home deployments)
3. Basic understanding of networking and security concepts

## Step 1: Deploy the Production API Server

### Running the Production Server

The production server uses Waitress, a production-quality WSGI server:

```bash
# Install requirements
pip install -r api/requirements.txt

# Run the production server
python api/production_server.py
```

### Command Line Options

You can customize the server settings:

```bash
# View all options
python api/production_server.py --help

# Run on a specific port with more threads
python api/production_server.py --port 8080 --threads 16

# If running behind a reverse proxy
python api/production_server.py --trusted-proxy
```

## Step 2: Configure Port Forwarding

For home deployments, you need to set up port forwarding on your router:

1. Log in to your router's admin interface (typically http://192.168.1.1)
2. Navigate to port forwarding settings
3. Create a new rule:
   - External port: 5000 (or your chosen port)
   - Internal IP: Your server's local IP address
   - Internal port: 5000 (or your chosen port)
   - Protocol: TCP
4. Save the settings

## Step 3: Security Considerations

### Firewall Configuration

If you're running a firewall on your server:

```bash
# For UFW (Ubuntu)
sudo ufw allow 5000/tcp

# For Windows Firewall
netsh advfirewall firewall add rule name="Ombra API" dir=in action=allow protocol=TCP localport=5000
```

### SSL/TLS for HTTPS

For proper security, set up HTTPS using a reverse proxy like Nginx or Caddy:

#### Nginx Configuration Example:

```nginx
server {
    listen 443 ssl;
    server_name your-ombra-node.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Step 4: Configure Browser Extension

Update the browser extension to connect to your public API:

1. Install the extension in Chrome/Edge
2. Click the Settings button (gear icon)
3. Enter your public API endpoint: `https://your-domain.com/api` (or http://your-public-ip:5000/api)
4. Click "Save API Settings" and "Test Connection"

## Step 5: Running as a System Service

### Windows (using NSSM):

1. Download NSSM from https://nssm.cc/
2. Run `nssm install OmbraNode`
3. Set the path to `python.exe` and arguments to `api/production_server.py`
4. Configure startup directory to your project folder
5. Set up logging and other options as needed
6. Click "Install service"

### Linux (systemd):

Create a file at `/etc/systemd/system/ombra-node.service`:

