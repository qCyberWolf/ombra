import os
from typing import Dict, Any, List
import socket

# Get default host IP for public network
def get_default_host():
    try:
        # Try to get a public-facing interface
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except:
        # Fall back to any non-localhost interface
        try:
            hostname = socket.gethostname()
            return socket.gethostbyname(hostname)
        except:
            # Last resort, use 0.0.0.0 to bind to all interfaces
            return "0.0.0.0"

# Default configuration
DEFAULT_CONFIG = {
    # Network settings - bind to all interfaces for public access
    "host": "0.0.0.0",  # Bind to all interfaces 
    "port": 9000,       # Port to listen on
    
    # Node settings
    "node_name": "Ombra-Public-Node",
    "max_peers": 50,    # Higher peer limit for public network
    
    # PoSync consensus settings
    "min_tx_confirmations": 5,  # Minimum confirmations for a transaction to be considered valid
    "tx_validation_count": 5,   # Number of previous transactions each new transaction must validate
    
    # Storage settings
    "data_dir": "./data",       # Directory to store blockchain data
    
    # Seed nodes for public network
    "seed_nodes": [
        # Add your known reliable seed nodes here
        # Format: "host:port"
    ],
    
    # Public network settings
    "public_mode": True,        # Enable public mode
    "max_connections": 200,     # Maximum concurrent connections 
    "broadcast_interval": 60,   # How often to broadcast node info (seconds)
    
    # Transaction settings
    "tx_fee": 0.001,  # Standard transaction fee
}

def get_config(config_file: str = None) -> Dict[str, Any]:
    """
    Load configuration from file or use defaults.
    
    Args:
        config_file: Path to config file (JSON)
        
    Returns:
        Dictionary with configuration settings
    """
    config = DEFAULT_CONFIG.copy()
    
    if config_file and os.path.exists(config_file):
        import json
        try:
            with open(config_file, 'r') as f:
                user_config = json.load(f)
                # Update default config with user values
                config.update(user_config)
        except Exception as e:
            print(f"Error loading config from {config_file}: {str(e)}")
            print("Using default configuration.")
    
    # Ensure data directory exists
    os.makedirs(config["data_dir"], exist_ok=True)
    
    return config

def save_config(config: Dict[str, Any], config_file: str) -> bool:
    """
    Save configuration to file.
    
    Args:
        config: Configuration dictionary
        config_file: Path to save the config
        
    Returns:
        True if successful, False otherwise
    """
    import json
    try:
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving config to {config_file}: {str(e)}")
        return False
