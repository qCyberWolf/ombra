"""
Fast API endpoints that respond immediately without blockchain operations
Used for health checks and non-blockchain operations
"""

from flask import Blueprint, jsonify, request
import time
import threading
import psutil

# Create Blueprint
fast_api = Blueprint('fast_api', __name__)

# Track system stats
last_check_time = 0
system_stats = {
    "cpu_percent": 0,
    "memory_percent": 0,
    "connections": 0
}

# Worker thread to update system stats without blocking
def update_system_stats():
    global system_stats, last_check_time
    
    while True:
        try:
            system_stats = {
                "cpu_percent": psutil.cpu_percent(interval=1),
                "memory_percent": psutil.virtual_memory().percent,
                "connections": len(psutil.net_connections())
            }
            last_check_time = time.time()
        except Exception as e:
            print(f"Error updating system stats: {str(e)}")
        finally:
            time.sleep(5)  # Update every 5 seconds

# Start the stats worker thread
stats_thread = threading.Thread(target=update_system_stats, daemon=True)
stats_thread.start()

@fast_api.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint that responds quickly"""
    return jsonify({
        "status": "ok", 
        "timestamp": time.time(),
        "service": "Ombra Blockchain API"
    })

@fast_api.route('/api/quick-status', methods=['GET'])
def quick_status():
    """Fast status endpoint that doesn't wait for blockchain operations"""
    node = None
    try:
        # Import at function level to avoid circular imports
        from api.api_server import node, blockchain_cache
        
        if not node or not node.running:
            return jsonify({
                "status": "initializing",
                "timestamp": time.time(),
                "system": system_stats
            })
            
        return jsonify({
            "status": "online",
            "node_id": node.node_id,
            "peers": len(node.network.peers) if node else 0,
            "pending_transactions": len(node.blockchain.pending_transactions) if node else 0,
            "timestamp": time.time(),
            "system": system_stats,
            "cached_stats": blockchain_cache.last_stats if blockchain_cache.last_updated > 0 else {"status": "calculating"}
        })
    except Exception as e:
        return jsonify({
            "status": "degraded",
            "error": str(e),
            "timestamp": time.time(),
            "system": system_stats
        })

@fast_api.route('/status/system', methods=['GET'])
def system_status():
    """System resource status - responds quickly without blockchain checks"""
    return jsonify({
        "status": "ok",
        "timestamp": time.time(),
        "last_check": last_check_time,
        "system": system_stats
    })

@fast_api.route('/', methods=['GET'])
def root_info():
    """Simple root endpoint for the API"""
    return jsonify({
        "status": "online",
        "service": "Ombra Blockchain API",
        "message": "Welcome to the Ombra Blockchain API. Use /api endpoints to interact with the blockchain.",
        "version": "1.0",
        "system_load": system_stats["cpu_percent"]
    })

# Error handling for fast endpoints
@fast_api.errorhandler(404)
def handle_404(e):
    return jsonify({"error": "Endpoint not found", "status": 404}), 404

@fast_api.errorhandler(500)
def handle_500(e):
    return jsonify({"error": "Internal server error", "status": 500}), 500
