import sys
import os
import json
import logging
import time
from flask import Flask, request, jsonify, Response, g, current_app
from flask_cors import CORS
from functools import wraps
import threading
import concurrent.futures
import queue
from werkzeug.middleware.proxy_fix import ProxyFix

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.wallet import Wallet
from core.transaction import Transaction
from core.blockchain import OmbraBlockchain
from network.node import OmbraNode
from config import get_config
from api.fast_endpoints import fast_api

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("api_server.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Create the Flask app
app = Flask(__name__)

# If behind a proxy, uncomment and configure this
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

# Register the fast_api blueprint for health checks and non-blockchain endpoints
app.register_blueprint(fast_api)

# Enable CORS
CORS(app)

# Set higher timeouts for gunicorn/waitress
app.config['PROPAGATE_EXCEPTIONS'] = True

# Global variables
node = None
wallets = {}  # Address -> Wallet object
last_request_times = {}  # IP -> last request timestamp
request_counts = {}  # IP -> request count in current time window
transaction_queue = queue.Queue()  # Queue for async transaction processing

# Create thread pools for different operations
read_pool = concurrent.futures.ThreadPoolExecutor(max_workers=8, thread_name_prefix="read")
write_pool = concurrent.futures.ThreadPoolExecutor(max_workers=4, thread_name_prefix="write")
tx_pool = concurrent.futures.ThreadPoolExecutor(max_workers=2, thread_name_prefix="tx")

# Rate limiting to protect public API
def rate_limit(max_requests=15, window=60):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            ip = request.remote_addr
            now = time.time()
            
            # Reset counter if outside window
            if ip in last_request_times and now - last_request_times[ip] > window:
                request_counts[ip] = 0
                
            # Update tracking
            last_request_times[ip] = now
            request_counts[ip] = request_counts.get(ip, 0) + 1
            
            # Check if rate limit exceeded
            if request_counts.get(ip, 0) > max_requests:
                logger.warning(f"Rate limit exceeded for IP: {ip}")
                return jsonify({
                    "error": "Rate limit exceeded",
                    "message": f"Maximum {max_requests} requests per {window} seconds"
                }), 429
                
            return f(*args, **kwargs)
        return wrapped
    return decorator

# Fix timeout support for API endpoints to prevent request context error
def with_timeout(timeout=10):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            # Store start time
            start_time = time.time()
            g.start_time = start_time
            
            # Capture request path within request context
            path = request.path if request else "unknown"

            # Set up a timeout checker that doesn't rely on request context
            def check_timeout():
                elapsed = time.time() - start_time
                if elapsed > timeout * 0.8:  # Warning at 80% of timeout
                    logger.warning(f"Request {path} taking too long: {elapsed:.2f}s")
            
            # Schedule timeout check
            if timeout > 0:
                timer = threading.Timer(timeout * 0.8, check_timeout)
                timer.daemon = True
                timer.start()
            
            result = f(*args, **kwargs)
            
            # Log timing for slow requests
            elapsed = time.time() - start_time
            if elapsed > 1.0:  # Log requests taking more than 1 second
                logger.info(f"Slow request {path}: {elapsed:.2f}s")
                
            return result
        return wrapped
    return decorator

# Start asynchronous transaction processor
def transaction_processor():
    """Process transactions in background thread"""
    while True:
        try:
            tx_job = transaction_queue.get()
            if tx_job is None:  # Sentinel value to stop the thread
                break
                
            tx, wallet = tx_job
            try:
                # Sign and add to blockchain
                tx.hash = tx.calculate_hash()
                wallet.sign_transaction(tx)
                success = node.add_transaction(tx)
                logger.info(f"Background transaction processing result: {success}, hash: {tx.hash[:8]}...")
            except Exception as e:
                logger.error(f"Error processing transaction: {str(e)}")
        except Exception as e:
            logger.error(f"Transaction processor error: {str(e)}")
        finally:
            transaction_queue.task_done()

# This class will store blockchain state information for fast access
class BlockchainCache:
    def __init__(self):
        self.last_stats = {
            "total_transactions": 0,
            "layers": 0,
            "confirmation_depth": 0
        }
        self.last_updated = 0
        self.update_interval = 10  # seconds
        self.is_updating = False

    def needs_update(self):
        return time.time() - self.last_updated > self.update_interval

    def update_stats(self, new_stats):
        self.last_stats = new_stats
        self.last_updated = time.time()
        self.is_updating = False

# Create a global cache object
blockchain_cache = BlockchainCache()

# Background thread to periodically update blockchain stats
def update_blockchain_stats_background():
    """Update blockchain stats in background"""
    while True:
        try:
            if node and node.running and blockchain_cache.needs_update() and not blockchain_cache.is_updating:
                blockchain_cache.is_updating = True
                stats = node.blockchain.get_ledger_stats()
                blockchain_cache.update_stats(stats)
        except Exception as e:
            logger.error(f"Error updating blockchain stats: {str(e)}")
            blockchain_cache.is_updating = False
        finally:
            time.sleep(5)  # Check every 5 seconds

# Add this class to manage node initialization status
class NodeInitializationStatus:
    def __init__(self):
        self.initialized = False
        self.error = None
        self.start_time = time.time()
        self.lock = threading.Lock()

    def set_initialized(self):
        with self.lock:
            self.initialized = True

    def set_error(self, error):
        with self.lock:
            self.error = error

    def get_status(self):
        with self.lock:
            return {
                "initialized": self.initialized,
                "error": str(self.error) if self.error else None,
                "startup_time": time.time() - self.start_time
            }

# Create a global initialization status object
node_init_status = NodeInitializationStatus()

def start_node():
    """Start the blockchain node in the background"""
    global node
    
    try:
        config = get_config(os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json"))
        
        # Create and start node
        node = OmbraNode(config["host"], config["port"])
        node.start()
        
        # Connect to seed nodes
        for seed in config.get("seed_nodes", []):
            try:
                host, port = seed.split(":")
                node.connect_to_network(host, int(port))
            except Exception as e:
                logger.error(f"Failed to connect to seed node {seed}: {str(e)}")
        
        logger.info(f"API server connected to Ombra node with ID: {node.node_id}")
        
        # Start transaction processor thread
        tx_processor = threading.Thread(target=transaction_processor, daemon=True)
        tx_processor.start()
        
        # Start blockchain stats background thread
        stats_thread = threading.Thread(target=update_blockchain_stats_background, daemon=True)
        stats_thread.start()

        # Mark node as successfully initialized
        node_init_status.set_initialized()
        
    except Exception as e:
        logger.error(f"Failed to initialize node: {str(e)}")
        node_init_status.set_error(e)
        # Retry initialization after delay
        retry_thread = threading.Thread(target=retry_node_start, args=(5,), daemon=True)
        retry_thread.start()

def retry_node_start(delay=5):
    """Retry node startup after a delay"""
    logger.info(f"Retrying node start in {delay} seconds...")
    time.sleep(delay)
    
    # Clear error status before retry
    node_init_status.error = None
    
    # Try to start the node again
    start_node_thread = threading.Thread(target=start_node, daemon=True)
    start_node_thread.start()

# Add a startup status endpoint
@app.route('/api/startup-status', methods=['GET'])
def get_startup_status():
    """Get node startup status"""
    status = node_init_status.get_status()
    if status["initialized"]:
        return jsonify({
            "status": "online",
            "node_id": node.node_id,
            "startup_time": status["startup_time"]
        })
    elif status["error"]:
        return jsonify({
            "status": "error",
            "error": status["error"],
            "startup_time": status["startup_time"]
        }), 500
    else:
        return jsonify({
            "status": "initializing",
            "startup_time": status["startup_time"]
        })

@app.route('/api/fast-status', methods=['GET'])
@rate_limit()
def get_fast_status():
    """Get minimal node status information instantly"""
    if not node or not node.running:
        return jsonify({"error": "Node not running"}), 503
        
    try:
        # Only include data that's instantly available - no calculations
        return jsonify({
            "node_id": node.node_id,
            "peers": len(node.network.peers),
            "pending_transactions": len(node.blockchain.pending_transactions),
            "server_time": time.time(),
            "response_type": "fast",
            "message": "Use /api/status for complete information"
        })
    except Exception as e:
        logger.error(f"Error in get_fast_status: {str(e)}")
        return jsonify({"error": "Internal server error", "details": str(e)}), 500

@app.route('/api/status', methods=['GET'])
@rate_limit()
@with_timeout(5)  # Should respond quickly
def get_status():
    """Get node status (optimized version)"""
    if not node or not node.running:
        status = node_init_status.get_status()
        if status["error"]:
            return jsonify({
                "error": "Node failed to start",
                "details": status["error"],
                "retry_in_progress": status["startup_time"] < 60  # Show retry status for first 60 seconds
            }), 503
        else:
            return jsonify({
                "error": "Node not running or initializing",
                "startup_time": status["startup_time"],
                "check_endpoint": "/api/startup-status"
            }), 503
        
    try:
        # Return cached stats immediately if available
        if not blockchain_cache.needs_update():
            stats = blockchain_cache.last_stats
        else:
            # If cache needs update, schedule update but don't wait for it
            if not blockchain_cache.is_updating:
                read_pool.submit(lambda: update_cache_async())
                
            # Use whatever we have, even if stale
            stats = blockchain_cache.last_stats
            if "total_transactions" not in stats or stats["total_transactions"] == 0:
                # If no stats are available at all, just return minimal data
                return get_fast_status()
        
        # Basic node info that's always fast to access
        pending_tx_count = len(node.blockchain.pending_transactions)
        peer_count = len(node.network.peers)
        
        return jsonify({
            "node_id": node.node_id,
            "peers": peer_count,
            "transactions": stats["total_transactions"],
            "layers": stats["layers"],
            "confirmation_depth": stats["confirmation_depth"],
            "pending_transactions": pending_tx_count,
            "server_time": time.time(),
            "cache_age": int(time.time() - blockchain_cache.last_updated) if blockchain_cache.last_updated > 0 else None
        })
    except Exception as e:
        # If anything fails, fall back to fast-status
        logger.error(f"Error in get_status: {str(e)}")
        return get_fast_status()

def update_cache_async():
    """Update blockchain cache in background"""
    try:
        blockchain_cache.is_updating = True
        stats = node.blockchain.get_ledger_stats()
        blockchain_cache.update_stats(stats)
    except Exception as e:
        logger.error(f"Error updating blockchain stats: {str(e)}")
        blockchain_cache.is_updating = False

@app.route('/api/wallet/create', methods=['POST'])
@rate_limit()
def create_wallet():
    """Create a new wallet"""
    try:
        wallet = Wallet()
        address = wallet.address
        wallets[address] = wallet
        
        # Return only public information
        return jsonify({
            "address": address,
            "public_key": wallet.get_public_key_pem()
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/wallet/import', methods=['POST'])
@rate_limit()
def import_wallet():
    """Import a wallet from private key"""
    data = request.json
    private_key = data.get('private_key')
    
    if not private_key:
        return jsonify({"error": "Private key required"}), 400
        
    try:
        # In a real implementation, you would import the key properly
        # This is simplified for demonstration
        wallet = Wallet()  # Create new wallet
        wallets[wallet.address] = wallet
        
        return jsonify({
            "address": wallet.address,
            "public_key": wallet.get_public_key_pem()
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/wallet/<address>/balance', methods=['GET'])
@rate_limit()
def get_balance(address):
    """Get wallet balance"""
    if not node or not node.running:
        return jsonify({"error": "Node not running"}), 503
    
    # Define a worker function to run in the thread pool
    def calculate_balance(addr):
        balance = 0
        txs = {}
        for tx_hash, tx in node.blockchain.ledger.transactions.items():
            if tx.recipient == addr:
                balance += tx.amount
                # Add to recent transactions
                if len(txs) < 5:
                    txs[tx_hash] = "received"
            if tx.sender == addr:
                balance -= tx.amount
                # Add to recent transactions
                if len(txs) < 5:
                    txs[tx_hash] = "sent"
                    
        return balance, txs
    
    try:
        # Execute balance calculation in thread pool
        future = read_pool.submit(calculate_balance, address)
        balance, recent_txs = future.result(timeout=10)
            
        return jsonify({
            "address": address,
            "balance": balance,
            "recent_transactions": len(recent_txs),
            "timestamp": time.time()
        })
    except concurrent.futures.TimeoutError:
        # Return error if calculation takes too long
        return jsonify({
            "error": "Balance calculation timed out", 
            "message": "Try again later or use a more specific query"
        }), 504
    except Exception as e:
        logger.error(f"Error calculating balance for {address}: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/wallet/<address>/transactions', methods=['GET'])
@rate_limit()
@with_timeout(30)  # Transactions might take longer
def get_transactions(address):
    """Get transactions related to an address"""
    if not node or not node.running:
        return jsonify({"error": "Node not running"}), 503
        
    try:
        # Get pagination parameters
        limit = min(int(request.args.get('limit', 50)), 100)  # Cap at 100 items
        page = max(int(request.args.get('page', 1)), 1)  # Minimum page 1
        
        # Define worker function for thread pool
        def fetch_transactions(addr, pg, lmt):
            transactions = []
            counter = 0
            page_start = (pg - 1) * lmt
            page_end = pg * lmt
            
            # Use more efficient transaction lookup
            tx_hashes = []
            
            # First quickly gather the relevant transaction hashes
            for tx_hash, tx in node.blockchain.ledger.transactions.items():
                if tx.sender == addr or tx.recipient == addr:
                    tx_hashes.append(tx_hash)
                    counter += 1
            
            # Sort by timestamp if possible (newest first)
            sorted_hashes = sorted(
                tx_hashes,
                key=lambda h: node.blockchain.ledger.transactions[h].timestamp,
                reverse=True
            )
            
            # Now extract the page we need
            page_hashes = sorted_hashes[page_start:page_end] if sorted_hashes else []
            
            # Get transaction details for this page
            for tx_hash in page_hashes:
                tx = node.blockchain.ledger.transactions[tx_hash]
                security = node.blockchain.ledger.get_transaction_security(tx_hash)
                transactions.append({
                    "hash": tx.hash,
                    "sender": tx.sender,
                    "recipient": tx.recipient,
                    "amount": tx.amount,
                    "timestamp": tx.timestamp,
                    "data": tx.data,
                    "confirmations": tx.confirmation_count,
                    "security": security
                })
            
            return transactions, counter
        
        # Execute in thread pool
        future = read_pool.submit(fetch_transactions, address, page, limit)
        transactions, total_count = future.result(timeout=25)
                    
        return jsonify({
            "address": address,
            "transactions": transactions,
            "total": total_count,
            "page": page,
            "limit": limit
        })
    except concurrent.futures.TimeoutError:
        logger.warning(f"Transaction fetch timed out for {address}")
        return jsonify({
            "error": "Transaction fetch timed out",
            "message": "Try with a smaller page size or fewer transactions"
        }), 504
    except Exception as e:
        logger.error(f"Error in get_transactions: {str(e)}")
        return jsonify({"error": "Internal server error", "details": str(e)}), 500

@app.route('/api/transaction/send', methods=['POST'])
@rate_limit()
def send_transaction():
    """Send a new transaction - this now queues transactions for async processing"""
    if not node or not node.running:
        return jsonify({"error": "Node not running"}), 503
        
    data = request.json
    sender_address = data.get('sender')
    recipient = data.get('recipient')
    amount = data.get('amount')
    tx_data = data.get('data', '')
    
    if not sender_address or not recipient or not amount:
        return jsonify({"error": "Sender, recipient and amount required"}), 400
        
    # Get sender wallet
    wallet = wallets.get(sender_address)
    if not wallet:
        return jsonify({"error": "Sender wallet not found"}), 404
        
    try:
        # Create transaction
        tx = wallet.create_transaction(recipient, float(amount), tx_data)
        
        # Function to get references
        def get_references():
            if node.blockchain.ledger.transaction_count > 0:
                references = node.blockchain.ledger.get_random_transactions(5)
                return [t.hash for t in references]
            return []
        
        # Get references in thread pool
        future = read_pool.submit(get_references)
        tx.previous_txs = future.result(timeout=5)
        
        if not tx.previous_txs:
            return jsonify({"error": "Not enough transactions in ledger for validation"}), 400
            
        # Queue transaction for background processing
        transaction_queue.put((tx, wallet))
        
        # Immediately return response
        return jsonify({
            "success": True,
            "transaction": tx.calculate_hash(),  # Pre-calculate hash for response
            "message": "Transaction submitted for processing",
            "queued_at": time.time()
        })
    except Exception as e:
        logger.error(f"Error in send_transaction: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/transaction/<tx_hash>', methods=['GET'])
@rate_limit()
def get_transaction(tx_hash):
    """Get transaction details"""
    if not node or not node.running:
        return jsonify({"error": "Node not running"}), 503
    
    try:
        # Define worker function for thread pool
        def fetch_transaction(hash):
            tx = node.blockchain.get_transaction(hash)
            if not tx:
                return None
                
            security = node.blockchain.ledger.get_transaction_security(hash)
            return {
                "hash": tx.hash,
                "sender": tx.sender,
                "recipient": tx.recipient,
                "amount": tx.amount,
                "timestamp": tx.timestamp,
                "data": tx.data,
                "confirmations": tx.confirmation_count,
                "security": security,
                "previous_txs": tx.previous_txs
            }
        
        # Execute in thread pool
        future = read_pool.submit(fetch_transaction, tx_hash)
        tx_data = future.result(timeout=10)
        
        if not tx_data:
            return jsonify({"error": "Transaction not found"}), 404
            
        return jsonify(tx_data)
    except concurrent.futures.TimeoutError:
        return jsonify({
            "error": "Transaction lookup timed out",
            "message": "The server is currently busy, try again later"
        }), 504
    except Exception as e:
        logger.error(f"Error fetching transaction {tx_hash}: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Handle 404 errors for /api/player_stats
@app.route('/api/player_stats', methods=['GET'])
def player_stats():
    """Handle player stats requests - currently not implemented"""
    return jsonify({
        "error": "Player stats not implemented in this version",
        "message": "This endpoint is not available in the Ombra blockchain API"
    }), 404

@app.errorhandler(504)
def gateway_timeout(error):
    """Handle gateway timeout errors"""
    logger.error(f"Gateway timeout error: {error}")
    return jsonify({
        "error": "Gateway timeout", 
        "message": "The server took too long to respond. Try a more specific query or try again later.",
        "status_code": 504
    }), 504

if __name__ == "__main__":
    # Start node in a separate thread
    node_thread = threading.Thread(target=start_node)
    node_thread.daemon = True
    node_thread.start()
    
    # Give the node more time to initialize (increased from 2 seconds)
    logger.info("Waiting for node initialization...")
    for _ in range(5):  # Wait up to 5 seconds, checking every second
        if node and node.running:
            logger.info("Node successfully initialized")
            break
        time.sleep(1)
    
    # Check if we should use production server
    production_mode = os.environ.get('OMBRA_PRODUCTION', 'false').lower() == 'true'
    
    if production_mode:
        # Use Waitress for Windows production deployment
        from waitress import serve
        print("Starting API server in PRODUCTION mode using Waitress")
        serve(app, host='0.0.0.0', port=5000, threads=8, channel_timeout=180)
    else:
        # Use Flask's development server
        print("Starting API server in DEVELOPMENT mode")
        app.run(host='127.0.0.1', port=5000, debug=True)
