"""
Production WSGI server for the Ombra blockchain API
Uses Waitress which is production-ready and works well on Windows
"""
import os
import sys
import socket
import logging
import argparse
import platform
import time  # Add time module import
import subprocess
# Only import resource module on Unix-like systems
if platform.system() != 'Windows':
    import resource
import psutil
from waitress import serve

# Configure logging - force ASCII encoding for Windows compatibility
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.FileHandler("ombra_api.log", encoding='utf-8'), 
              logging.StreamHandler()]
)
logger = logging.getLogger("ombra-api")

# Set production flag
os.environ['OMBRA_PRODUCTION'] = 'true'

# Import the Flask app (which will now use production mode)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from api.api_server import app

# Get server resources
def get_system_resources():
    """Get available system resources"""
    resources = {
        "cpu_count": psutil.cpu_count(),
        "memory_gb": round(psutil.virtual_memory().total / (1024**3), 2)
    }
    
    # Calculate recommended thread count based on CPU cores
    resources["recommended_threads"] = min(resources["cpu_count"] * 2 + 1, 20)
    return resources

# Get server IP addresses for display purposes
def get_server_ips():
    ips = {
        'localhost': '127.0.0.1',
        'local_network': None
    }
    
    try:
        # Get local network IP (for LAN access)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # Doesn't actually connect but gets local interface
        s.connect(('8.8.8.8', 1))
        ips['local_network'] = s.getsockname()[0]
        s.close()
    except:
        # If we can't determine local IP, use hostname resolution
        try:
            ips['local_network'] = socket.gethostbyname(socket.gethostname())
        except:
            ips['local_network'] = "unknown"
            
    return ips

def check_port_availability(host, port):
    """Check if port is already in use"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex((host, port))
    sock.close()
    return result != 0

def configure_windows_firewall(port):
    """Configure Windows firewall to allow inbound connections"""
    if platform.system() != 'Windows':
        return False
    
    try:
        # Check if rule already exists
        check_cmd = f'netsh advfirewall firewall show rule name="Ombra API Server Port {port}"'
        rule_exists = True
        try:
            subprocess.check_output(check_cmd, shell=True)
        except subprocess.CalledProcessError:
            rule_exists = False
        
        if not rule_exists:
            logger.info(f"[SECURITY] Creating Windows Firewall rule for port {port}")
            cmd = f'netsh advfirewall firewall add rule name="Ombra API Server Port {port}" dir=in action=allow protocol=TCP localport={port}'
            subprocess.check_output(cmd, shell=True)
            logger.info(f"[SECURITY] Successfully added firewall rule")
            return True
        else:
            logger.info(f"[SECURITY] Firewall rule already exists for port {port}")
            return True
    except Exception as e:
        logger.warning(f"[SECURITY] Failed to configure Windows Firewall: {str(e)}")
        logger.warning(f"[SECURITY] You may need to manually allow connections to port {port}")
        return False

def try_get_public_ip():
    """Try to determine public IP address"""
    try:
        import urllib.request
        external_ip = urllib.request.urlopen('https://api.ipify.org').read().decode('utf8')
        return external_ip
    except:
        return None

if __name__ == '__main__':
    # Get system resources for recommendations
    system_resources = get_system_resources()
    
    parser = argparse.ArgumentParser(description='Ombra API Production Server')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind to (default: 0.0.0.0 - all interfaces)')
    parser.add_argument('--port', type=int, default=5000, help='Port to listen on (default: 5000)')
    parser.add_argument('--threads', type=int, default=system_resources["recommended_threads"], 
                      help=f'Number of worker threads (default: {system_resources["recommended_threads"]}, based on CPU count)')
    parser.add_argument('--trusted-proxy', action='store_true', help='Enable if behind a reverse proxy')
    parser.add_argument('--timeout', type=int, default=180, help='Timeout in seconds (default: 180)')
    parser.add_argument('--connection-limit', type=int, default=1000, help='Maximum connections (default: 1000)')
    parser.add_argument('--max-request-size', type=int, default=10, help='Maximum request body size in MB (default: 10)')
    parser.add_argument('--auto-firewall', action='store_true', help='Automatically configure Windows Firewall')
    parser.add_argument('--explicit-node-init', action='store_true', help='Wait for complete node initialization before starting')
    args = parser.parse_args()

    # Configuration
    HOST = args.host
    PORT = args.port
    THREADS = args.threads
    TIMEOUT = args.timeout
    CONNECTION_LIMIT = args.connection_limit
    MAX_REQUEST_SIZE = args.max_request_size * 1024 * 1024  # Convert MB to bytes
    
    # Check if port is already in use
    if not check_port_availability(HOST, PORT):
        logger.error(f"[ERROR] Port {PORT} is already in use.")
        logger.error(f"[HELP] Try running with a different port: --port {PORT+1}")
        sys.exit(1)
    
    # Configure firewall if requested and on Windows
    if args.auto_firewall:
        configure_windows_firewall(PORT)
    
    # Display access information with correct connection URLs
    ip_addresses = get_server_ips()
    
    logger.info("[LAUNCH] Starting Ombra API in PRODUCTION mode")
    logger.info(f"[SYSTEM] CPU cores: {system_resources['cpu_count']}, Memory: {system_resources['memory_gb']}GB")
    logger.info(f"[NETWORK] Server binding to {HOST}:{PORT}")
    logger.info(f"[CONFIG] Using {THREADS} worker threads with {TIMEOUT}s timeout")
    
    # Try to get public IP for better connection info
    public_ip = try_get_public_ip()
    
    # Show actual URLs clients should use - NEVER 0.0.0.0
    if HOST == '0.0.0.0':
        logger.info(f"[ACCESS] Local access URL: http://localhost:{PORT}")
        logger.info(f"[ACCESS] Network access URL: http://{ip_addresses['local_network']}:{PORT}")
        if public_ip:
            logger.info(f"[ACCESS] Public access URL (if port forwarded): http://{public_ip}:{PORT}")
        logger.info(f"[CONNECTION] Browser extension should use: http://{ip_addresses['local_network']}:{PORT}/api")
        logger.info(f"[PERFORMANCE] For faster response, use: http://{ip_addresses['local_network']}:{PORT}/api/fast-status")
    else:
        logger.info(f"[ACCESS] Server accessible at: http://{HOST}:{PORT}")
        logger.info(f"[CONNECTION] Browser extension should use: http://{HOST}:{PORT}/api")
        logger.info(f"[PERFORMANCE] For faster response, use: http://{HOST}:{PORT}/api/fast-status")
    
    # Security warning
    logger.warning("[SECURITY] WARNING: API is now accessible to anyone who can reach this server!")
    
    if platform.system() == "Windows" and not args.auto_firewall:
        logger.warning("[SECURITY] For external access, you may need to configure Windows Firewall manually")
        logger.warning("[SECURITY] You can use --auto-firewall to automatically add a firewall rule")
    
    # Wait for complete node initialization if requested
    if args.explicit_node_init:
        from api.api_server import node_init_status
        
        logger.info("[STARTUP] Waiting for complete node initialization...")
        max_wait = 30  # Maximum seconds to wait
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            status = node_init_status.get_status()
            if status["initialized"]:
                logger.info(f"[STARTUP] Node successfully initialized after {status['startup_time']:.2f} seconds")
                break
            elif status["error"]:
                logger.error(f"[STARTUP] Node initialization failed: {status['error']}")
                logger.info("[STARTUP] Continuing anyway - API will report node errors to clients")
                break
                
            time.sleep(1)
            sys.stdout.write(".")
            sys.stdout.flush()
        else:
            logger.warning(f"[STARTUP] Node initialization timed out after {max_wait} seconds")
            logger.info("[STARTUP] Continuing anyway - API will report node status to clients")
    
    try:
        # Start the production server with improved settings
        logger.info("[STARTUP] Launching server with extended timeout and optimized settings...")
        serve(
            app, 
            host=HOST, 
            port=PORT, 
            threads=THREADS,
            trusted_proxy=args.trusted_proxy,
            url_scheme='http',
            channel_timeout=TIMEOUT,
            asyncore_use_poll=True,
            clear_untrusted_proxy_headers=True,
            connection_limit=CONNECTION_LIMIT,
            max_request_header_size=16384,
            max_request_body_size=MAX_REQUEST_SIZE,
            cleanup_interval=60,
            ident='Ombra/1.0',
            backlog=1024,
            recv_bytes=65536
        )
    except OSError as e:
        if "socket.error" in str(e) or "address already in use" in str(e).lower():
            logger.error(f"[ERROR] Port {PORT} is already in use. Choose a different port with --port option.")
            logger.error(f"[HELP] Try running: python api/production_server.py --port {PORT+1}")
        else:
            logger.error(f"[ERROR] Failed to start server: {str(e)}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"[ERROR] Server failed to start: {str(e)}")
        sys.exit(1)
