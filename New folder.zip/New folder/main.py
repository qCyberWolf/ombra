#!/usr/bin/env python3
"""
Ombra Blockchain - Proof-of-Synchronization (PoSync) Implementation
Main entry point for running an Ombra node or CLI
"""

import sys
import os
import argparse
from typing import Dict, Any, List

# Make sure the current directory is in the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Use absolute imports
from cli.cli import OmbraCLI
from network.node import OmbraNode
from config import get_config

def parse_args():
    """Parse command-line arguments"""
    parser = argparse.ArgumentParser(description="Ombra Blockchain Node")
    
    parser.add_argument("--config", help="Path to config file")
    parser.add_argument("--port", type=int, help="Port to listen on")
    parser.add_argument("--host", help="Host to bind to")
    parser.add_argument("--data-dir", help="Data directory")
    parser.add_argument("--cli", action="store_true", help="Start interactive CLI")
    parser.add_argument("--connect", help="Connect to a peer node (host:port)")
    parser.add_argument("--seed", action="append", help="Add a seed node (can be used multiple times)")
    
    return parser.parse_args()

def main():
    """Main entry point"""
    args = parse_args()
    
    # Load configuration (from file if specified)
    config = get_config(args.config)
    
    # Override config with command-line arguments
    if args.port:
        config["port"] = args.port
    if args.host:
        config["host"] = args.host
    if args.data_dir:
        config["data_dir"] = args.data_dir
    if args.seed:
        config["seed_nodes"] = args.seed
    
    if args.cli:
        # Start interactive CLI
        cli = OmbraCLI(args.config)
        cli.cmdloop()
    else:
        # Start regular node
        print("\n💫 Starting Ombra Blockchain Node 💫")
        print(f"- PoSync Consensus Algorithm")
        print(f"- Multi-Layered Ledger Architecture")
        print(f"- Byzantine Mesh Protocol\n")
        
        # Create and start node
        node = OmbraNode(config["host"], config["port"])
        node.start()
        
        # Connect to seed nodes
        for seed in config["seed_nodes"]:
            host, port = seed.split(":")
            node.connect_to_network(host, int(port))
            
        # Connect to specified peer if any
        if args.connect:
            host, port = args.connect.split(":")
            node.connect_to_network(host, int(port))
        
        try:
            # Keep the main thread alive
            while True:
                import time
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nShutting down Ombra node...")
            node.stop()
            print("Node stopped. Goodbye!")
            
if __name__ == "__main__":
    main()
