import os
import json
import base64
import hashlib
from typing import Dict, Tuple, Optional, Any

from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding

from .transaction import Transaction

class Wallet:
    """
    Wallet implementation for the Ombra blockchain.
    Handles key generation, transaction creation and signing.
    """
    
    def __init__(self, keyfile_path: Optional[str] = None):
        """Initialize a wallet with a key pair"""
        self.private_key = None
        self.public_key = None
        self.address = ""
        
        if keyfile_path and os.path.exists(keyfile_path):
            self.load_keys(keyfile_path)
        else:
            self.generate_keys()
    
    def generate_keys(self) -> None:
        """Generate a new key pair"""
        # Generate private key
        self.private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        
        # Get public key
        self.public_key = self.private_key.public_key()
        
        # Generate address from public key
        public_bytes = self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        self.address = hashlib.sha256(public_bytes).hexdigest()
    
    def save_keys(self, keyfile_path: str, passphrase: Optional[str] = None) -> None:
        """Save keys to a file"""
        encryption_algorithm = serialization.BestAvailableEncryption(passphrase.encode()) if passphrase else serialization.NoEncryption()
        
        # Serialize private key
        private_pem = self.private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=encryption_algorithm
        )
        
        # Serialize public key
        public_pem = self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        # Save to file
        with open(keyfile_path, 'wb') as f:
            key_data = {
                "private_key": base64.b64encode(private_pem).decode('utf-8'),
                "public_key": base64.b64encode(public_pem).decode('utf-8'),
                "address": self.address
            }
            f.write(json.dumps(key_data).encode())
    
    def load_keys(self, keyfile_path: str, passphrase: Optional[str] = None) -> bool:
        """Load keys from a file"""
        try:
            with open(keyfile_path, 'r') as f:
                key_data = json.load(f)
            
            private_pem = base64.b64decode(key_data["private_key"])
            public_pem = base64.b64decode(key_data["public_key"])
            
            self.private_key = serialization.load_pem_private_key(
                private_pem,
                password=passphrase.encode() if passphrase else None
            )
            
            self.public_key = serialization.load_pem_public_key(public_pem)
            self.address = key_data["address"]
            return True
        except Exception as e:
            print(f"Failed to load wallet: {str(e)}")
            return False
    
    def create_transaction(self, recipient: str, amount: float, 
                         data: str = "") -> Transaction:
        """Create a new transaction"""
        tx = Transaction(
            sender=self.address,
            recipient=recipient,
            amount=amount,
            data=data
        )
        
        # Hash will be calculated later when previous_txs are assigned
        return tx
    
    def sign_transaction(self, tx: Transaction) -> None:
        """Sign a transaction with the private key"""
        if not self.private_key:
            raise ValueError("Private key not available")
            
        tx.hash = tx.calculate_hash()
        tx.sign(self.private_key)
    
    def get_public_key_pem(self) -> str:
        """Get public key in PEM format"""
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode('utf-8')
