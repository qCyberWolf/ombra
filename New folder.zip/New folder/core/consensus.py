import time
import random
from typing import List, Dict, Any, Set
from .transaction import Transaction

class ProofOfSync:
    """
    Implementation of the Proof-of-Synchronization (PoSync) consensus algorithm.
    
    In PoSync:
    1. Each transaction validates multiple previous transactions
    2. A transaction is confirmed when subsequent transactions reference it
    3. Confirmation depth increases security exponentially
    """
    
    @staticmethod
    def select_transactions_to_validate(available_txs: List[Transaction], 
                                       count: int = 5) -> List[Transaction]:
        """
        Select transactions that need validation.
        Prefers transactions with fewer confirmations.
        """
        if len(available_txs) <= count:
            return available_txs
            
        # Sort by confirmation count (prefer less confirmed transactions)
        sorted_txs = sorted(available_txs, key=lambda tx: tx.confirmation_count)
        return sorted_txs[:count]
    
    @staticmethod
    def validate_transaction(tx: Transaction, ledger_state: Dict[str, Any]) -> bool:
        """
        Validate a transaction according to PoSync rules:
        - Transaction must have valid signature
        - Transaction must reference valid previous transactions
        - Referenced transactions must exist in the ledger
        """
        # Check basic validity (signature, format)
        if not tx.validate():
            return False
            
        # Ensure the transaction references valid previous transactions
        for prev_tx_hash in tx.previous_txs:
            if prev_tx_hash not in ledger_state:
                return False
        
        # Check double-spending
        sender_balance = ProofOfSync.calculate_balance(tx.sender, ledger_state)
        if tx.amount > sender_balance and tx.sender != "0":  # Allow genesis tx
            return False
            
        return True
    
    @staticmethod
    def calculate_balance(address: str, ledger_state: Dict[str, Any]) -> float:
        """Calculate balance for an address based on the current ledger state"""
        balance = 0.0
        
        for tx_hash, tx_data in ledger_state.items():
            if tx_data['recipient'] == address:
                balance += tx_data['amount']
            elif tx_data['sender'] == address:
                balance -= tx_data['amount']
                
        return balance
    
    @staticmethod
    def calculate_transaction_security(tx: Transaction, 
                                     confirmation_depth: int) -> float:
        """
        Calculate the security level of a transaction based on:
        - Number of confirmations
        - Depth in the ledger
        - Synchronization layers
        
        Returns a value between 0.0 (unconfirmed) and 1.0 (maximum security)
        """
        # Base security from direct confirmations
        base_security = min(tx.confirmation_count / 10.0, 0.5)
        
        # Additional security from depth in the ledger
        depth_security = min(confirmation_depth / 20.0, 0.5)
        
        # Combined security level (max 1.0)
        return min(base_security + depth_security, 1.0)
