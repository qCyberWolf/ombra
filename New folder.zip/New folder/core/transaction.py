import time
import hashlib
import json
from typing import List, Dict, Any, Optional
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization

class Transaction:
    """
    Transaction class for the Ombra blockchain.
    
    In PoSync, each transaction must validate multiple previous transactions
    before it can be added to the ledger.
    """
    
    def __init__(self, sender: str, recipient: str, amount: float, 
                timestamp: Optional[int] = None, data: str = "", 
                previous_txs: List[str] = None):
        self.sender = sender
        self.recipient = recipient
        self.amount = amount
        self.timestamp = timestamp or int(time.time())
        self.data = data
        self.previous_txs = previous_txs or []
        self.hash = ""
        self.signature = ""
        self.confirmation_count = 0
        
    def calculate_hash(self) -> str:
        """Calculate the hash of the transaction"""
        tx_dict = {
            "sender": self.sender,
            "recipient": self.recipient,
            "amount": self.amount,
            "timestamp": self.timestamp,
            "data": self.data,
            "previous_txs": self.previous_txs
        }
        
        # Create a sorted, deterministic JSON string
        tx_string = json.dumps(tx_dict, sort_keys=True)
        return hashlib.sha256(tx_string.encode()).hexdigest()
    
    def sign(self, private_key) -> None:
        """Sign the transaction with the sender's private key"""
        if isinstance(private_key, str):
            # Convert PEM string to private key object if needed
            private_key = serialization.load_pem_private_key(
                private_key.encode(),
                password=None
            )
            
        # Create signature
        signature = private_key.sign(
            self.hash.encode(),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        self.signature = signature.hex()
    
    def validate(self) -> bool:
        """
        Validate the transaction:
        1. Check that hash is correct
        2. Check that signature is valid (except genesis)
        3. Verify it has correct number of previous tx references
        """
        # Verify hash
        if self.hash != self.calculate_hash():
            return False
            
        # Genesis transaction validation
        if self.sender == "0" and self.recipient == "0":
            return True
            
        # Regular transaction validation
        # 1. Must have previous transactions for PoSync (except genesis)
        if not self.previous_txs:
            return False
            
        # 2. Should have a valid signature (skipped here as we'd need the public key)
        # In a real implementation, we'd verify the signature using the sender's public key
        
        return True
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert transaction to dictionary for serialization"""
        return {
            "sender": self.sender,
            "recipient": self.recipient,
            "amount": self.amount,
            "timestamp": self.timestamp,
            "data": self.data,
            "previous_txs": self.previous_txs,
            "hash": self.hash,
            "signature": self.signature,
            "confirmation_count": self.confirmation_count
        }
        
    @staticmethod
    def from_dict(tx_dict: Dict[str, Any]) -> 'Transaction':
        """Create a Transaction object from a dictionary"""
        tx = Transaction(
            sender=tx_dict["sender"],
            recipient=tx_dict["recipient"],
            amount=tx_dict["amount"],
            timestamp=tx_dict["timestamp"],
            data=tx_dict["data"],
            previous_txs=tx_dict["previous_txs"]
        )
        tx.hash = tx_dict["hash"]
        tx.signature = tx_dict["signature"]
        tx.confirmation_count = tx_dict["confirmation_count"]
        return tx
