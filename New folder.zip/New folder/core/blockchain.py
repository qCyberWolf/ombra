import time
import hashlib
import json
from typing import List, Dict, Any, Optional
from .transaction import Transaction
from .ledger import MultiLayeredLedger
import threading

class OmbraBlockchain:
    """
    Main blockchain class implementing Proof-of-Synchronization (PoSync) consensus.
    Uses a Multi-Layered Ledger instead of traditional blocks.
    """
    def __init__(self):
        self.ledger = MultiLayeredLedger()
        self.pending_transactions = []
        self.node_id = hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]
        self._stats_cache = {}
        self._stats_lock = threading.RLock()
        self._last_stats_update = 0
        print(f"Initialized Ombra node with ID: {self.node_id}")
        
    def create_genesis_transaction(self) -> None:
        """Create the genesis transaction that starts the ledger"""
        genesis = Transaction(
            sender="0",
            recipient="0",
            amount=0,
            timestamp=int(time.time()),
            data="Genesis Transaction",
            previous_txs=[]
        )
        genesis.hash = genesis.calculate_hash()
        genesis.signature = "GENESIS_SIGNATURE"
        self.ledger.add_transaction(genesis)
        
    def add_transaction(self, transaction: Transaction) -> bool:
        """Add a transaction to the pending pool"""
        if transaction.validate():
            self.pending_transactions.append(transaction)
            return True
        return False
        
    def process_pending_transactions(self) -> List[str]:
        """Process all pending transactions with PoSync consensus"""
        processed_tx_hashes = []
        
        for transaction in self.pending_transactions:
            # Select 5 previous transactions for validation
            references = self.ledger.get_random_transactions(5)
            transaction.previous_txs = [tx.hash for tx in references]
            
            # Verify the references exist and are valid
            if self.ledger.verify_transaction_references(transaction):
                transaction.hash = transaction.calculate_hash()
                self.ledger.add_transaction(transaction)
                processed_tx_hashes.append(transaction.hash)
            
        # Clear processed transactions
        self.pending_transactions = [tx for tx in self.pending_transactions 
                                   if tx.hash not in processed_tx_hashes]
        
        # Invalidate stats cache after processing transactions
        with self._stats_lock:
            self._last_stats_update = 0
            
        return processed_tx_hashes
    
    def get_transaction(self, tx_hash: str) -> Optional[Transaction]:
        """Get a transaction by its hash"""
        return self.ledger.get_transaction(tx_hash)
    
    def get_ledger_stats(self) -> Dict[str, Any]:
        """Get statistics about the ledger (with caching)"""
        with self._stats_lock:
            current_time = time.time()
            # Return cached stats if recent (within 10 seconds)
            if self._last_stats_update > 0 and (current_time - self._last_stats_update) < 10:
                return self._stats_cache.copy()
                
            # Fast path for minimum info
            if hasattr(self, '_min_stats_cache') and self._min_stats_cache:
                # If called again within 2 seconds, return minimal stats
                if hasattr(self, '_last_min_stats_time') and (current_time - self._last_min_stats_time) < 2:
                    return self._min_stats_cache
            
            # Quickly calculate minimal stats
            min_stats = {
                "total_transactions": self.ledger.transaction_count,
                "layers": len(self.ledger.layers) if hasattr(self.ledger, 'layers') else 0,
                "confirmation_depth": 0  # This is expensive to calculate, so we postpone
            }
            
            # Store minimal stats
            self._min_stats_cache = min_stats
            self._last_min_stats_time = current_time
            
            # For full stats, start a thread to calculate them in the background
            if not hasattr(self, '_stats_calculating') or not self._stats_calculating:
                self._stats_calculating = True
                
                def calculate_full_stats():
                    try:
                        # Calculate the more expensive confirmation depth
                        full_stats = min_stats.copy()
                        full_stats["confirmation_depth"] = self.ledger.get_average_confirmation_depth()
                        
                        # Update cache with full stats
                        with self._stats_lock:
                            self._stats_cache = full_stats
                            self._last_stats_update = time.time()
                            self._stats_calculating = False
                    except Exception as e:
                        print(f"Error calculating full stats: {str(e)}")
                        self._stats_calculating = False
                        
                import threading
                stats_thread = threading.Thread(target=calculate_full_stats)
                stats_thread.daemon = True
                stats_thread.start()
                
            return min_stats
