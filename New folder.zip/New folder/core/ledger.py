import random
import time
from typing import List, Dict, Any, Optional, Set
from .transaction import Transaction

class MultiLayeredLedger:
    """
    Multi-Layered Ledger (MLL) implementation for the Ombra blockchain.
    
    Instead of traditional blocks, transactions are stored in multiple
    synchronization layers, creating a mesh of validations.
    """
    
    def __init__(self):
        self.transactions = {}  # hash -> Transaction
        self.layers = {}        # layer_id -> [tx_hashes]
        self.references = {}    # tx_hash -> [referencing_tx_hashes]
        self.current_layer = 0
        self.transaction_count = 0
        
    @property
    def layer_count(self) -> int:
        """Get the total number of layers"""
        return self.current_layer + 1
        
    def add_transaction(self, transaction: Transaction) -> bool:
        """
        Add a transaction to the ledger and update its synchronization layer.
        The layer is determined by the maximum layer of referenced transactions + 1.
        """
        # Skip if already in ledger
        if transaction.hash in self.transactions:
            return False
            
        # Find the appropriate layer
        if not transaction.previous_txs:  # Genesis transaction
            tx_layer = 0
        else:
            # Transaction goes into layer above its highest reference
            max_ref_layer = -1
            for prev_tx_hash in transaction.previous_txs:
                if prev_tx_hash in self.transactions:
                    for layer_id, tx_hashes in self.layers.items():
                        if prev_tx_hash in tx_hashes and layer_id > max_ref_layer:
                            max_ref_layer = layer_id
            
            tx_layer = max_ref_layer + 1
            
        # Create the layer if it doesn't exist
        if tx_layer not in self.layers:
            self.layers[tx_layer] = []
            self.current_layer = max(self.current_layer, tx_layer)
            
        # Add to the layer
        self.layers[tx_layer].append(transaction.hash)
        
        # Store the transaction
        self.transactions[transaction.hash] = transaction
        self.transaction_count += 1
        
        # Update reference tracking for confirmation counting
        for prev_tx_hash in transaction.previous_txs:
            if prev_tx_hash not in self.references:
                self.references[prev_tx_hash] = []
            self.references[prev_tx_hash].append(transaction.hash)
            
            # Increment confirmation count on the referenced transaction
            if prev_tx_hash in self.transactions:
                self.transactions[prev_tx_hash].confirmation_count += 1
                
        return True
                
    def get_transaction(self, tx_hash: str) -> Optional[Transaction]:
        """Get a transaction by its hash"""
        return self.transactions.get(tx_hash)
        
    def get_transactions_in_layer(self, layer_id: int) -> List[Transaction]:
        """Get all transactions in a specific layer"""
        if layer_id not in self.layers:
            return []
            
        return [self.transactions[tx_hash] for tx_hash in self.layers[layer_id]]
        
    def get_random_transactions(self, count: int) -> List[Transaction]:
        """Get random transactions from the ledger for validation"""
        tx_count = min(count, len(self.transactions))
        if tx_count == 0:
            return []
            
        # Prioritize transactions with fewer confirmations
        all_txs = list(self.transactions.values())
        sorted_txs = sorted(all_txs, key=lambda tx: tx.confirmation_count)
        return sorted_txs[:tx_count]
    
    def verify_transaction_references(self, transaction: Transaction) -> bool:
        """Verify that all referenced transactions exist in the ledger"""
        return all(tx_hash in self.transactions for tx_hash in transaction.previous_txs)
    
    def get_average_confirmation_depth(self) -> float:
        """Calculate the average confirmation depth across all transactions"""
        if not self.transactions:
            return 0.0
            
        total_confirmations = sum(tx.confirmation_count for tx in self.transactions.values())
        return total_confirmations / len(self.transactions)
    
    def get_transaction_security(self, tx_hash: str) -> float:
        """
        Calculate the security level of a transaction based on:
        - Number of direct confirmations
        - Depth in the ledger (layer position)
        """
        if tx_hash not in self.transactions:
            return 0.0
            
        tx = self.transactions[tx_hash]
        
        # Find which layer contains this transaction
        tx_layer = None
        for layer_id, hashes in self.layers.items():
            if tx_hash in hashes:
                tx_layer = layer_id
                break
                
        if tx_layer is None:
            return 0.0
            
        # Calculate depth from the latest layer
        depth = self.current_layer - tx_layer
        
        # Security grows with confirmations and depth
        confirmation_factor = min(tx.confirmation_count / 10.0, 0.6)
        depth_factor = min(depth / (self.layer_count * 0.5), 0.4)
        
        return confirmation_factor + depth_factor
