import time
import json
from typing import Dict, List, Any, Optional, Tuple
import shlex
import os
import socket
import sys

# Add parent directory to sys.path for absolute imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def execute_command(command_line: str, node=None, wallet=None) -> Any:
    """
    Execute custom CLI commands
    
    Args:
        command_line: Command line string
        node: OmbraNode instance
        wallet: Wallet instance
        
    Returns:
        Command output
    """
    try:
        args = shlex.split(command_line)
        command = args[0]
        
        # Get command handler
        if command in COMMANDS:
            handler = COMMANDS[command]
            return handler(args[1:], node, wallet)
        else:
            print(f"Unknown command: {command}")
    except Exception as e:
        print(f"Error executing command: {str(e)}")

def cmd_list_transactions(args, node, wallet) -> None:
    """List transactions in the ledger"""
    if not node:
        print("Node not initialized")
        return
        
    try:
        count = int(args[0]) if args else 10
    except ValueError:
        count = 10
        
    ledger = node.blockchain.ledger
    txs = []
    
    # Get transactions, starting from the latest layers
    for layer_id in sorted(ledger.layers.keys(), reverse=True):
        for tx_hash in ledger.layers[layer_id]:
            tx = ledger.transactions[tx_hash]
            txs.append({
                "hash": tx.hash[:10] + "...",
                "sender": tx.sender[:8] + "..." if len(tx.sender) > 8 else tx.sender,
                "recipient": tx.recipient[:8] + "..." if len(tx.recipient) > 8 else tx.recipient,
                "amount": tx.amount,
                "time": time.strftime("%Y-%m-%d %H:%M", time.localtime(tx.timestamp)),
                "confirmations": tx.confirmation_count
            })
            if len(txs) >= count:
                break
        if len(txs) >= count:
            break
            
    if not txs:
        print("No transactions found")
        return
        
    print("\nLatest Transactions:")
    print(f"{'HASH':<12} {'SENDER':<12} {'RECIPIENT':<12} {'AMOUNT':<10} {'TIME':<16} {'CONFIRMATIONS':<12}")
    print("-" * 75)
    
    for tx in txs:
        print(f"{tx['hash']:<12} {tx['sender']:<12} {tx['recipient']:<12} {tx['amount']:<10.2f} {tx['time']:<16} {tx['confirmations']:<12}")
        
def cmd_layers(args, node, wallet) -> None:
    """Show information about ledger layers"""
    if not node:
        print("Node not initialized")
        return
        
    ledger = node.blockchain.ledger
    
    print("\nLedger Layers:")
    print(f"{'LAYER':<6} {'TRANSACTIONS':<12} {'AVG SECURITY':<12}")
    print("-" * 32)
    
    for layer_id in sorted(ledger.layers.keys()):
        tx_hashes = ledger.layers[layer_id]
        tx_count = len(tx_hashes)
        
        # Calculate average security for transactions in this layer
        total_security = sum(ledger.get_transaction_security(tx_hash) for tx_hash in tx_hashes)
        avg_security = total_security / tx_count if tx_count > 0 else 0
        
        print(f"{layer_id:<6} {tx_count:<12} {avg_security:.4f}")
        
def cmd_export(args, node, wallet) -> None:
    """Export ledger to a file"""
    if not node:
        print("Node not initialized")
        return
        
    file_path = args[0] if args else "ledger_export.json"
    
    ledger = node.blockchain.ledger
    export_data = {
        "transaction_count": ledger.transaction_count,
        "layer_count": ledger.layer_count,
        "layers": {str(layer_id): tx_hashes for layer_id, tx_hashes in ledger.layers.items()},
        "transactions": {}
    }
    
    # Add transactions data
    for tx_hash, tx in ledger.transactions.items():
        export_data["transactions"][tx_hash] = tx.to_dict()
        
    try:
        with open(file_path, 'w') as f:
            json.dump(export_data, f, indent=2)
        print(f"Ledger exported to {file_path}")
    except Exception as e:
        print(f"Export failed: {str(e)}")
        
def cmd_network(args, node, wallet) -> None:
    """Show network information"""
    if not node or not node.running:
        print("Node not running")
        return
        
    print("\nNetwork Information:")
    print(f"Node ID: {node.node_id}")
    print(f"Listening on: {node.network.host}:{node.network.port}")
    print(f"Connected peers: {len(node.network.peers)}")
    
    # Get local IP for easier connection from other machines
    local_ip = socket.gethostbyname(socket.gethostname())
    print(f"Local IP: {local_ip}")
    
    # Show peers
    if node.network.peers:
        print("\nPeers:")
        for i, (peer_id, (host, port)) in enumerate(node.network.peers.items()):
            print(f"  {i+1}. {peer_id} - {host}:{port}")
            
def cmd_sync(args, node, wallet) -> None:
    """Force sync with the network"""
    if not node or not node.running:
        print("Node not running")
        return
        
    if not node.network.peers:
        print("No peers connected. Use 'connect' command first.")
        return
        
    print("Initiating sync with peers...")
    node._request_sync_from_random_peer()
    print("Sync request sent")
    
def cmd_balance(args, node, wallet) -> None:
    """Show balance of an address"""
    if not node:
        print("Node not initialized")
        return
        
    address = args[0] if args else wallet.address if wallet else None
    if not address:
        print("Provide an address or initialize wallet first")
        return
        
    # Calculate balance by traversing ledger
    balance = 0
    for tx_hash, tx in node.blockchain.ledger.transactions.items():
        if tx.recipient == address:
            balance += tx.amount
        if tx.sender == address:
            balance -= tx.amount
            
    print(f"Balance for {address[:8]}...: {balance}")

# Dictionary of available commands
COMMANDS = {
    "txs": cmd_list_transactions,
    "transactions": cmd_list_transactions,
    "layers": cmd_layers,
    "export": cmd_export,
    "network": cmd_network,
    "sync": cmd_sync,
    "balance": cmd_balance,
}
