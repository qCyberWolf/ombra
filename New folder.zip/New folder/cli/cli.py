import cmd
import sys
import os
import time
from typing import List, Dict, Any, Optional
import argparse
import json

# Add parent directory to sys.path to allow absolute imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Replace relative imports with absolute imports
from core.blockchain import OmbraBlockchain
from core.wallet import Wallet
from core.transaction import Transaction
from network.node import OmbraNode
from cli.commands import execute_command

class OmbraCLI(cmd.Cmd):
    """
    Command-line interface for interacting with the Ombra blockchain.
    """
    
    prompt = "ombra> "
    intro = """
    ┌─────────────────────────────────────────────────────┐
    │                  OMBRA BLOCKCHAIN                   │
    │           Proof-of-Synchronization (PoSync)         │
    └─────────────────────────────────────────────────────┘
    
    Type 'help' for available commands.
    """
    
    def __init__(self, config_file: Optional[str] = None):
        super().__init__()
        self.node = None
        self.wallet = None
        self.config = self._load_config(config_file)
        self.data_dir = self.config.get("data_dir", "./data")
        self.wallet_file = os.path.join(self.data_dir, "wallet.dat")
        
        # Create data directory if needed
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Initialize wallet
        self._init_wallet()
        
    def _load_config(self, config_file: Optional[str]) -> Dict[str, Any]:
        """Load configuration settings"""
        default_config = {
            "host": "127.0.0.1",
            "port": 9000,
            "data_dir": "./data",
            "seed_nodes": []
        }
        
        if config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    return {**default_config, **config}
            except:
                print(f"Error loading config from {config_file}. Using defaults.")
                
        return default_config
        
    def _init_wallet(self) -> None:
        """Initialize or load wallet"""
        try:
            if os.path.exists(self.wallet_file):
                self.wallet = Wallet(self.wallet_file)
                print(f"Wallet loaded with address: {self.wallet.address[:8]}...")
            else:
                self.wallet = Wallet()
                self.wallet.save_keys(self.wallet_file)
                print(f"New wallet created with address: {self.wallet.address[:8]}...")
        except Exception as e:
            print(f"Error initializing wallet: {str(e)}")
            
    def do_start(self, arg) -> None:
        """Start the blockchain node: start [port]"""
        if self.node and self.node.running:
            print("Node is already running")
            return
            
        try:
            args = arg.split()
            port = int(args[0]) if args else self.config.get("port", 9000)
            
            host = self.config.get("host", "127.0.0.1")
            self.node = OmbraNode(host, port)
            self.node.start()
            
            # Connect to seed nodes
            for seed in self.config.get("seed_nodes", []):
                seed_host, seed_port = seed.split(":")
                self.node.connect_to_network(seed_host, int(seed_port))
                
            print(f"Node started on {host}:{port} with ID: {self.node.node_id}")
        except Exception as e:
            print(f"Error starting node: {str(e)}")
            
    def do_stop(self, arg) -> None:
        """Stop the blockchain node"""
        if self.node and self.node.running:
            self.node.stop()
            print("Node stopped")
        else:
            print("Node is not running")
            
    def do_status(self, arg) -> None:
        """Show the status of the node and ledger"""
        if not self.node:
            print("Node is not initialized. Use 'start' command first.")
            return
            
        stats = self.node.blockchain.get_ledger_stats()
        peers = len(self.node.network.peers)
        pending = len(self.node.blockchain.pending_transactions)
        
        print("\n---- Ombra Node Status ----")
        print(f"Node ID: {self.node.node_id}")
        print(f"Connected peers: {peers}")
        print(f"Total transactions: {stats['total_transactions']}")
        print(f"Layers: {stats['layers']}")
        print(f"Avg. confirmation depth: {stats['confirmation_depth']:.2f}")
        print(f"Pending transactions: {pending}")
        print("--------------------------\n")
        
    def do_wallet(self, arg) -> None:
        """Wallet operations: wallet [info|new|export]"""
        args = arg.split()
        cmd = args[0] if args else "info"
        
        if cmd == "info":
            if not self.wallet:
                print("No wallet loaded")
                return
                
            print(f"\nWallet Address: {self.wallet.address}")
            print(f"Public Key: {self.wallet.get_public_key_pem()[:64]}...")
            
            if self.node:
                # Get balance (if node is running)
                balance = 0  # Replace with actual balance calculation
                print(f"Balance: {balance}")
                
        elif cmd == "new":
            self.wallet = Wallet()
            self.wallet.save_keys(self.wallet_file)
            print(f"New wallet created with address: {self.wallet.address}")
            
        elif cmd == "export":
            if not self.wallet:
                print("No wallet loaded")
                return
                
            export_file = args[1] if len(args) > 1 else "wallet_export.json"
            try:
                self.wallet.save_keys(export_file)
                print(f"Wallet exported to {export_file}")
            except Exception as e:
                print(f"Error exporting wallet: {str(e)}")
        else:
            print("Unknown wallet command. Use: wallet [info|new|export]")
            
    def do_send(self, arg) -> None:
        """Send tokens: send <recipient> <amount> [data]"""
        if not self.node or not self.node.running:
            print("Node is not running. Use 'start' command first.")
            return
            
        args = arg.split()
        if len(args) < 2:
            print("Usage: send <recipient> <amount> [data]")
            return
            
        recipient = args[0]
        try:
            amount = float(args[1])
        except ValueError:
            print("Amount must be a number")
            return
            
        data = " ".join(args[2:]) if len(args) > 2 else ""
        
        # Create and sign transaction
        tx = self.wallet.create_transaction(recipient, amount, data)
        
        # Get previous transactions for validation
        if self.node.blockchain.ledger.transaction_count > 0:
            references = self.node.blockchain.ledger.get_random_transactions(5)
            tx.previous_txs = [t.hash for t in references]
        else:
            print("Not enough transactions in the ledger for validation")
            return
            
        tx.hash = tx.calculate_hash()
        self.wallet.sign_transaction(tx)
        
        # Add to blockchain
        if self.node.add_transaction(tx):
            print(f"Transaction sent! Hash: {tx.hash[:16]}...")
        else:
            print("Failed to send transaction")
            
    def do_tx(self, arg) -> None:
        """View transaction details: tx <hash>"""
        if not self.node:
            print("Node is not initialized. Use 'start' command first.")
            return
            
        tx_hash = arg.strip()
        if not tx_hash:
            print("Usage: tx <hash>")
            return
            
        tx = self.node.blockchain.get_transaction(tx_hash)
        if not tx:
            print(f"Transaction {tx_hash} not found")
            return
            
        security = self.node.blockchain.ledger.get_transaction_security(tx_hash)
        
        print(f"\nTransaction: {tx.hash}")
        print(f"Sender: {tx.sender}")
        print(f"Recipient: {tx.recipient}")
        print(f"Amount: {tx.amount}")
        print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(tx.timestamp))}")
        print(f"Data: {tx.data}")
        print(f"Confirmation count: {tx.confirmation_count}")
        print(f"Security level: {security:.4f} ({int(security * 100)}%)")
        print(f"Referenced transactions: {len(tx.previous_txs)}")
        for i, ref_tx in enumerate(tx.previous_txs):
            print(f"  {i+1}. {ref_tx}")
            
    def do_peers(self, arg) -> None:
        """List connected peers: peers"""
        if not self.node or not self.node.running:
            print("Node is not running")
            return
            
        if not self.node.network.peers:
            print("No peers connected")
            return
            
        print("\nConnected peers:")
        for i, (peer_id, (host, port)) in enumerate(self.node.network.peers.items()):
            print(f"{i+1}. {peer_id} - {host}:{port}")
            
    def do_connect(self, arg) -> None:
        """Connect to a peer: connect <host> <port>"""
        if not self.node or not self.node.running:
            print("Node is not running. Use 'start' command first.")
            return
            
        args = arg.split()
        if len(args) < 2:
            print("Usage: connect <host> <port>")
            return
            
        host = args[0]
        try:
            port = int(args[1])
        except ValueError:
            print("Port must be a number")
            return
        
        # Validate host before attempting connection
        if host == "localhost":
            print("Note: When connecting from remote peers, 'localhost' won't work. Using 127.0.0.1...")
            host = "127.0.0.1" 
        
        print(f"Attempting to connect to {host}:{port}...")
        if self.node.connect_to_network(host, port):
            print(f"Successfully connected to {host}:{port}")
        else:
            print(f"Failed to connect to {host}:{port}")
            
    def do_exit(self, arg) -> bool:
        """Exit the CLI"""
        if self.node and self.node.running:
            self.node.stop()
        print("Goodbye!")
        return True
        
    def default(self, line) -> None:
        """Handle custom commands"""
        try:
            execute_command(line, self.node, self.wallet)
        except Exception as e:
            print(f"Error: {str(e)}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ombra Blockchain CLI")
    parser.add_argument("--config", help="Path to config file")
    args = parser.parse_args()
    
    cli = OmbraCLI(args.config)
    cli.cmdloop()
