"""
Check Ombra Node Status and Troubleshoot Issues
"""
import requests
import time
import sys
import socket
import os
import subprocess

def print_header(text):
    print("\n" + "=" * 50)
    print(text)
    print("=" * 50)

def check_api_running(host="localhost", port=5000):
    """Check if API server is running"""
    print_header("Checking API Server")
    
    try:
        response = requests.get(f"http://{host}:{port}/health", timeout=5)
        if response.status_code == 200:
            print("✅ API server is running")
            return True
        else:
            print(f"❌ API server returned status code {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ API server is not running or unreachable")
        return False
    except Exception as e:
        print(f"❌ Error checking API: {str(e)}")
        return False

def check_node_status(host="localhost", port=5000):
    """Check blockchain node status"""
    print_header("Checking Blockchain Node")
    
    try:
        # First check startup status endpoint
        startup_response = requests.get(f"http://{host}:{port}/api/startup-status", timeout=5)
        startup_data = startup_response.json()
        
        if startup_response.status_code == 200 and startup_data.get("status") == "online":
            print(f"✅ Node is running with ID: {startup_data.get('node_id')}")
            print(f"   Startup time: {startup_data.get('startup_time'):.2f} seconds")
            return True
        else:
            print(f"⚠️ Node initialization status: {startup_data.get('status')}")
            if 'error' in startup_data:
                print(f"   Error: {startup_data.get('error')}")
            print(f"   Time elapsed: {startup_data.get('startup_time'):.2f} seconds")
            
            # Try to check regular status endpoint too
            try:
                status_response = requests.get(f"http://{host}:{port}/api/status", timeout=5)
                if status_response.status_code == 503:
                    error_data = status_response.json()
                    print(f"⚠️ Status endpoint confirms node is not running")
                    if "details" in error_data:
                        print(f"   Error details: {error_data.get('details')}")
                    if error_data.get("retry_in_progress"):
                        print(f"   Retry is in progress...")
            except:
                # Ignore errors querying status endpoint
                pass
                
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to API server")
        return False
    except Exception as e:
        print(f"❌ Error checking node status: {str(e)}")
        return False

def check_config_file():
    """Check if config file exists and is valid"""
    print_header("Checking Configuration")
    
    config_path = os.path.join(os.path.dirname(__file__), "config.json")
    if not os.path.exists(config_path):
        print("❌ Config file not found: config.json")
        print("   Create a config.json file with the following minimal content:")
        print('   {"host": "0.0.0.0", "port": 9000, "seed_nodes": []}')
        return False
    else:
        print("✅ Config file exists")
        
        # Check if the file is valid JSON
        try:
            import json
            with open(config_path, 'r') as f:
                config = json.load(f)
                print("✅ Config file is valid JSON")
                
                # Check for required fields
                required_fields = ["host", "port"]
                missing_fields = [field for field in required_fields if field not in config]
                if missing_fields:
                    print(f"⚠️ Config is missing required fields: {', '.join(missing_fields)}")
                    return False
                    
                return True
        except json.JSONDecodeError:
            print("❌ Config file is not valid JSON")
            return False
        except Exception as e:
            print(f"❌ Error checking config file: {str(e)}")
            return False

def restart_api_server():
    """Restart API server with explicit node initialization"""
    print_header("Restarting API Server")
    
    print("🔄 Stopping any running servers...")
    # Windows version - find and kill process on port 5000
    if sys.platform == 'win32':
        try:
            cmd = 'netstat -ano | findstr :5000'
            output = subprocess.check_output(cmd, shell=True).decode()
            for line in output.splitlines():
                if "LISTENING" in line:
                    pid = line.split()[-1]
                    kill_cmd = f"taskkill /PID {pid} /F"
                    subprocess.call(kill_cmd, shell=True)
                    print(f"✅ Killed process {pid} on port 5000")
        except:
            print("✅ No process found running on port 5000")
    
    # Start the API server with explicit node initialization
    print("\n🔄 Starting API server with explicit node initialization...")
    if sys.platform == 'win32':
        subprocess.Popen(["start", "cmd", "/k", "python", "api/production_server.py", "--explicit-node-init"], shell=True)
    else:
        subprocess.Popen(["python", "api/production_server.py", "--explicit-node-init"], 
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for server to start
    print("\n🔄 Waiting for server to initialize...")
    for i in range(10):
        time.sleep(1)
        print(".", end="", flush=True)
        try:
            response = requests.get("http://localhost:5000/health", timeout=1)
            if response.status_code == 200:
                print("\n✅ API server started successfully")
                break
        except:
            pass
    print("\n")

def display_troubleshooting_steps():
    """Display troubleshooting steps"""
    print_header("Troubleshooting Steps")
    print("1. Check if the config.json file is valid and has the correct settings")
    print("2. Make sure no other service is using port 5000")
    print("3. Try running the server with explicit node initialization:")
    print("   python api/production_server.py --explicit-node-init")
    print("4. Check the api_server.log file for errors")
    print("5. Ensure all required modules are installed:")
    print("   pip install -r api/requirements.txt")

def main():
    print("\n=== Ombra Node Status Checker ===\n")
    
    # Check if API is running
    api_running = check_api_running()
    
    # Check node status if API is running
    node_running = check_node_status() if api_running else False
    
    # Check config file
    config_ok = check_config_file()
    
    # Summarize findings
    print_header("Summary")
    
    if api_running and node_running and config_ok:
        print("✅ Everything appears to be working correctly!")
        print("✅ API server is running")
        print("✅ Blockchain node is running")
        print("✅ Configuration is valid")
    else:
        print("⚠️ Issues detected:")
        if not api_running:
            print("❌ API server is not running")
        elif not node_running:
            print("❌ API server is running but blockchain node failed to initialize")
        if not config_ok:
            print("❌ Configuration issues detected")
        
        # Show troubleshooting options
        display_troubleshooting_steps()
        
        # Ask if user wants to restart the server
        if api_running and not node_running:
            answer = input("\nWould you like to restart the API server with explicit node initialization? (y/n): ")
            if answer.lower() == 'y':
                restart_api_server()
                print("\nServer is restarting. Please check status in a few moments with:")
                print("python check_node_status.py")

if __name__ == "__main__":
    main()
