# Ombra Blockchain

A next-generation blockchain implementation using **Proof-of-Synchronization** (PoSync) consensus algorithm.

## Core Features

- ✅ **Proof-of-Synchronization (PoSync)**: No mining, no staking, transactions validate each other
- ✅ **Multi-Layered Ledger (MLL)**: Self-verifying transaction structure instead of traditional blocks
- ✅ **Byzantine Mesh Protocol**: Highly secure, resistant to 51% attacks
- ✅ **Millisecond Finality**: Near-instant transaction confirmation
- ✅ **True Decentralization**: No miners, validators, or leader nodes

## How It Works

Unlike traditional blockchains that group transactions into sequential blocks, Ombra uses a multi-layered mesh architecture:

1. **Every transaction validates multiple previous transactions**
2. **Transaction security increases with each new layer of validation**
3. **The network becomes more secure as activity increases**

## Quick Start

### Prerequisites

- Python 3.7+
- Install requirements: `pip install -r requirements.txt`

### Running a Node

```bash
# Start a node with default settings
python main.py

# Start a node with custom port
python main.py --port 9001

# Connect to another node
python main.py --connect 127.0.0.1:9000
```

### Interactive CLI

```bash
# Start the CLI
python main.py --cli

# Available commands:
# start - Start the node
# status - Show node status
# wallet - Manage your wallet
# send - Send tokens
# tx - View transaction details
# peers - View connected peers
# connect - Connect to a peer
```

## Technical Components

- **Multi-Layered Ledger**: Transactions organized in layers based on validation relationships
- **PoSync Consensus**: Deterministic algorithm where transactions confirm each other
- **P2P Network**: Fully decentralized network communication
- **Wallet Management**: Secure key generation and transaction signing

## Security Features

- **Impossible to 51% Attack**: No single chain to rewrite
- **No Reorganization Risk**: Past transactions get deeply embedded in the mesh
- **Self-Healing Security**: The network adapts to attacks automatically
- **Byzantine Fault Tolerance**: The system remains operational even if some nodes fail

## Project Structure

