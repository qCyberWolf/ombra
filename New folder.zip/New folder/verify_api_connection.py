"""
Verify connection to Ombra API Server at specific IP address
"""
import requests
import sys
import json
import time
import socket
import os
import platform
import subprocess

# Target API server - make configurable via command line args
DEFAULT_PORT = 5000

def print_status(message, is_success=None):
    """Print status message with color if possible"""
    if is_success is None:
        print(f"[*] {message}")
    elif is_success:
        print(f"[✓] {message}")
    else:
        print(f"[✗] {message}")

def get_windows_error_description(error_code):
    """Get description for Windows socket error codes"""
    error_descriptions = {
        10035: "Resource temporarily unavailable (WSAEWOULDBLOCK) - The server socket may not be in blocking mode",
        10054: "Connection reset by peer (WSAECONNRESET) - The server actively refused the connection",
        10061: "Connection refused (WSAECONNREFUSED) - No server is listening on that port",
        10060: "Connection timed out (WSAETIMEDOUT) - Server might be behind firewall or down",
        10065: "No route to host (WSAEHOSTUNREACH) - Network routing issue, check internet connection"
    }
    return error_descriptions.get(error_code, f"Unknown error code ({error_code})")

def check_local_server():
    """Check if server is running locally"""
    print_status("Checking if Ombra API server is running locally...")
    
    # Check on localhost first
    local_result = check_port_open("127.0.0.1", DEFAULT_PORT)
    if local_result == 0:
        print_status(f"Server is running locally on port {DEFAULT_PORT}", True)
        return True
    else:
        print_status(f"Server is NOT running locally on port {DEFAULT_PORT}", False)
        # On Windows, check for process using port 5000
        if platform.system() == "Windows":
            try:
                # Run netstat to check if port is in use
                cmd = f'netstat -ano | findstr :{DEFAULT_PORT}'
                result = subprocess.check_output(cmd, shell=True).decode()
                if result.strip():
                    print_status(f"Port {DEFAULT_PORT} is in use by another process:", False)
                    print(result)
            except subprocess.CalledProcessError:
                pass
        return False

def check_port_open(host, port, timeout=2):
    """Check if a port is open on a host"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result
    except socket.error:
        return -1

def check_network_connectivity(host, port):
    """Check if the target IP is reachable at network level"""
    print_status(f"Testing network connectivity to {host}...")
    
    try:
        # Create a socket and try to connect to the target port
        result = check_port_open(host, port)
        
        if result == 0:
            print_status(f"Port {port} is open on {host}", True)
            return True
        else:
            print_status(f"Port {port} is not accessible on {host}", False)
            
            # Provide more detailed error info for Windows
            if platform.system() == "Windows":
                error_desc = get_windows_error_description(result)
                print(f"    Reason: {error_desc}")
                
            return False
    except socket.gaierror:
        print_status(f"Hostname {host} could not be resolved", False)
        return False
    except socket.error as e:
        print_status(f"Network error: {str(e)}", False)
        return False

def check_router_forwarding(port):
    """Check if router may need port forwarding configured"""
    # Get local and public IP to see if behind NAT
    print_status("\nChecking network configuration...")
    local_ip = get_local_ip()
    
    try:
        # Try to get public IP
        response = requests.get("https://api.ipify.org?format=json", timeout=5)
        public_ip = response.json()["ip"]
        
        if local_ip != public_ip:
            print_status(f"Local IP ({local_ip}) differs from public IP ({public_ip})")
            print_status(f"You are behind a NAT/router and will need port forwarding")
            
            # Check if port forwarding is working
            forward_check = check_port_open(public_ip, port)
            if forward_check == 0:
                print_status("Port forwarding appears to be working", True)
            else:
                print_status("Port forwarding does not appear to be configured", False)
                print_status("You need to set up port forwarding on your router:")
                print(f"  → Forward external port {port} to internal IP {local_ip}:{port}")
    except:
        print_status("Could not determine public IP", False)

def get_local_ip():
    """Get local IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 1))  # connecting to a UDP address doesn't send packets
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except:
        return "127.0.0.1"

def check_api_endpoints(host, port):
    """Check various API endpoints to verify functionality"""
    base_url = f"http://{host}:{port}"
    endpoints = [
        {"path": "/", "name": "Root endpoint", "timeout": 3},
        {"path": "/health", "name": "Health check", "timeout": 3},
        {"path": "/api/fast-status", "name": "Fast status", "timeout": 3},
        {"path": "/api/status", "name": "Full status", "timeout": 5}
    ]
    
    print_status("\nTesting API endpoints:")
    all_success = True
    
    for endpoint in endpoints:
        url = f"{base_url}{endpoint['path']}"
        try:
            print_status(f"Requesting {url}...")
            start_time = time.time()
            response = requests.get(url, timeout=endpoint["timeout"])
            elapsed = time.time() - start_time
            
            if response.status_code == 200:
                data = response.json()
                print_status(f"{endpoint['name']}: OK ({elapsed:.2f}s)", True)
                if endpoint["path"] != "/":
                    print(f"    Response: {json.dumps(data, indent=2)[:200]}...")
            else:
                print_status(f"{endpoint['name']}: Failed with status {response.status_code}", False)
                all_success = False
        except requests.exceptions.Timeout:
            print_status(f"{endpoint['name']}: Timed out after {endpoint['timeout']} seconds", False)
            all_success = False
        except requests.exceptions.ConnectionError:
            print_status(f"{endpoint['name']}: Connection error", False)
            all_success = False
        except Exception as e:
            print_status(f"{endpoint['name']}: Error - {str(e)}", False)
            all_success = False
            
    return all_success

def generate_server_config():
    """Generate a production server configuration file"""
    local_ip = get_local_ip()
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "public_server.bat")
    
    with open(config_path, "w") as f:
        f.write(f"""@echo off
REM Ombra Public API Server Configuration
echo ===============================
echo Ombra Public API Server
echo ===============================
echo.

SET OMBRA_PRODUCTION=true
SET PORT=5000
SET THREADS=16
SET TIMEOUT=300
SET CONNECTION_LIMIT=2000

echo Your server will be accessible at:
echo - Local URL:      http://localhost:5000
echo - Local Network:  http://{local_ip}:5000
echo - Internet (if port forwarded): http://YOUR_PUBLIC_IP:5000
echo.
echo Starting optimized API server...
echo.

python api/production_server.py --host 0.0.0.0 --port %PORT% --threads %THREADS% --timeout %TIMEOUT% --connection-limit %CONNECTION_LIMIT%

echo.
echo Server stopped. Press any key to exit.
pause > nul
""")
    print_status(f"\nGenerated server config: {config_path}")
    print(f"Run this file to start your public server: public_server.bat")

def recommend_browser_extension_settings(success, host, port):
    """Provide recommendations for browser extension settings"""
    print("\n" + "="*60)
    print("BROWSER EXTENSION CONNECTION SETTINGS")
    print("="*60)
    
    if success:
        print("\nTo connect your browser extension to this API server:")
        print(f"1. Open the extension settings")
        print(f"2. Enter this API URL: http://{host}:{port}/api")
        print(f"3. Click 'Save API Settings' and then 'Test Connection'")
        print("\nRecommended endpoint for best performance:")
        print(f"http://{host}:{port}/api/fast-status")
    else:
        print("\nCould not fully verify API connection.")
        print("If your API server is running properly, check:")
        print("1. Firewall settings - make sure port 5000 is open")
        print("2. Server configuration - verify it's binding to 0.0.0.0 (all interfaces)")
        print("3. Network configuration - check if port forwarding is correctly set up")
        print("\nTroubleshooting steps:")
        print("1. Run the server with: python api/production_server.py --host 0.0.0.0")
        print("2. Check Windows Firewall settings for port 5000")
        print("3. Configure port forwarding on your router if accessing from outside")

def main():
    print("\n== OMBRA API CONNECTION VERIFICATION ==\n")
    
    # Process command line arguments
    host = "localhost"
    port = DEFAULT_PORT
    
    if len(sys.argv) >= 2:
        host = sys.argv[1]
    if len(sys.argv) >= 3 and sys.argv[2].isdigit():
        port = int(sys.argv[2])
        
    # First check if server is running locally
    is_local_running = check_local_server()
    
    # Then check specified host
    if host != "localhost" and host != "127.0.0.1":
        # Check if we need to configure port forwarding
        check_router_forwarding(port)
        
        # Step 1: Check if we can reach the server
        network_ok = check_network_connectivity(host, port)
        if not network_ok:
            print("\nCannot establish network connection to the server.")
            print("\nTroubleshooting tips:")
            print("1. Verify the server is running with: python api/production_server.py --host 0.0.0.0")
            print("2. Check firewall settings to allow connections on port 5000")
            print("3. Ensure port forwarding is configured if behind NAT/router")
            
            # Generate a server config for public access
            generate_server_config()
            return
        
        # Step 2: Check API endpoints
        api_ok = check_api_endpoints(host, port)
        
        # Step 3: Provide recommendations
        recommend_browser_extension_settings(api_ok, host, port)
    else:
        if is_local_running:
            # Get local IP for better connection strings
            local_ip = get_local_ip()
            # Check API endpoints on localhost
            api_ok = check_api_endpoints("localhost", port)
            # Provide recommendations
            recommend_browser_extension_settings(api_ok, local_ip, port)
            
            # Generate a server config for public access
            generate_server_config()
        else:
            print("\nTo get started:")
            print("1. Start the API server with: python api/production_server.py")
            print("2. Run this verification script again")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nVerification canceled by user.")
    except Exception as e:
        print(f"\nAn error occurred during verification: {str(e)}")
