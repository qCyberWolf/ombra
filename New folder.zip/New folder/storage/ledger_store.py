import os
import json
import pickle
import time
from typing import Dict, Any, List, Optional
import threading
import sys

# Add parent directory to sys.path for absolute imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Replace relative imports with absolute imports
from core.transaction import Transaction
from core.ledger import MultiLayeredLedger

class LedgerStore:
    """
    Persistent storage for the Multi-Layered Ledger.
    
    Handles saving and loading the ledger to/from disk,
    transaction indexing, and efficient query capabilities.
    """
    
    def __init__(self, data_dir: str):
        """Initialize the ledger store with a data directory"""
        self.data_dir = data_dir
        self.tx_dir = os.path.join(data_dir, "transactions")
        self.metadata_file = os.path.join(data_dir, "metadata.json")
        
        # Create directories if they don't exist
        os.makedirs(self.data_dir, exist_ok=True)
        os.makedirs(self.tx_dir, exist_ok=True)
        
        # Create lock for thread safety
        self.lock = threading.RLock()
        
        # Metadata about the ledger
        self.metadata = {
            "transaction_count": 0,
            "layer_count": 0,
            "last_saved": 0
        }
        
        # Load metadata if exists
        if os.path.exists(self.metadata_file):
            self._load_metadata()
    
    def _load_metadata(self) -> None:
        """Load metadata from file"""
        try:
            with open(self.metadata_file, 'r') as f:
                self.metadata = json.load(f)
        except Exception as e:
            print(f"Error loading metadata: {str(e)}")
    
    def _save_metadata(self) -> None:
        """Save metadata to file"""
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            print(f"Error saving metadata: {str(e)}")
    
    def save_transaction(self, tx: Transaction) -> bool:
        """Save a single transaction to disk"""
        with self.lock:
            try:
                tx_path = os.path.join(self.tx_dir, f"{tx.hash}.json")
                with open(tx_path, 'w') as f:
                    json.dump(tx.to_dict(), f, indent=2)
                return True
            except Exception as e:
                print(f"Error saving transaction {tx.hash}: {str(e)}")
                return False
    
    def load_transaction(self, tx_hash: str) -> Optional[Transaction]:
        """Load a transaction from disk"""
        with self.lock:
            try:
                tx_path = os.path.join(self.tx_dir, f"{tx_hash}.json")
                if not os.path.exists(tx_path):
                    return None
                    
                with open(tx_path, 'r') as f:
                    tx_dict = json.load(f)
                    
                return Transaction.from_dict(tx_dict)
            except Exception as e:
                print(f"Error loading transaction {tx_hash}: {str(e)}")
                return None
    
    def save_ledger(self, ledger: MultiLayeredLedger) -> bool:
        """Save the entire ledger to disk"""
        with self.lock:
            try:
                # Save each transaction
                for tx_hash, transaction in ledger.transactions.items():
                    self.save_transaction(transaction)
                
                # Save layers structure
                layers_file = os.path.join(self.data_dir, "layers.json")
                with open(layers_file, 'w') as f:
                    json.dump(ledger.layers, f, indent=2)
                
                # Save references structure
                references_file = os.path.join(self.data_dir, "references.json")
                with open(references_file, 'w') as f:
                    json.dump(ledger.references, f, indent=2)
                
                # Update metadata
                self.metadata["transaction_count"] = ledger.transaction_count
                self.metadata["layer_count"] = ledger.layer_count
                self.metadata["last_saved"] = int(time.time())
                self._save_metadata()
                
                return True
            except Exception as e:
                print(f"Error saving ledger: {str(e)}")
                return False
    
    def load_ledger(self) -> Optional[MultiLayeredLedger]:
        """Load the entire ledger from disk"""
        with self.lock:
            try:
                ledger = MultiLayeredLedger()
                
                # Load layers structure
                layers_file = os.path.join(self.data_dir, "layers.json")
                if os.path.exists(layers_file):
                    with open(layers_file, 'r') as f:
                        # JSON converts keys to strings, so convert back to ints
                        layers_dict = json.load(f)
                        ledger.layers = {int(k): v for k, v in layers_dict.items()}
                
                # Load references structure
                references_file = os.path.join(self.data_dir, "references.json")
                if os.path.exists(references_file):
                    with open(references_file, 'r') as f:
                        ledger.references = json.load(f)
                
                # Load transactions
                for layer_id, tx_hashes in ledger.layers.items():
                    for tx_hash in tx_hashes:
                        tx = self.load_transaction(tx_hash)
                        if tx:
                            ledger.transactions[tx_hash] = tx
                
                # Update transaction count
                ledger.transaction_count = len(ledger.transactions)
                
                # Find current layer
                if ledger.layers:
                    ledger.current_layer = max(map(int, ledger.layers.keys()))
                
                return ledger
            except Exception as e:
                print(f"Error loading ledger: {str(e)}")
                return None
    
    def export_ledger_to_json(self, file_path: str, ledger: MultiLayeredLedger) -> bool:
        """Export the ledger to a single JSON file for analysis or backup"""
        try:
            export_data = {
                "metadata": {
                    "transaction_count": ledger.transaction_count,
                    "layer_count": ledger.layer_count,
                    "timestamp": int(time.time())
                },
                "transactions": {tx_hash: tx.to_dict() for tx_hash, tx in ledger.transactions.items()},
                "layers": ledger.layers,
                "references": ledger.references
            }
            
            with open(file_path, 'w') as f:
                json.dump(export_data, f, indent=2)
                
            return True
        except Exception as e:
            print(f"Error exporting ledger: {str(e)}")
            return False
