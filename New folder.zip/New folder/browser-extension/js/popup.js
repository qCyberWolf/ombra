// Initialize wallet when popup opens
const wallet = new OmbraWallet();
let nodeStatus = {};

// DOM elements
const screens = {
  login: document.getElementById('loginScreen'),
  import: document.getElementById('importScreen'),
  wallet: document.getElementById('walletScreen')
};

const elements = {
  networkStatus: document.getElementById('networkStatus'),
  walletAddress: document.getElementById('walletAddress'),
  walletBalance: document.getElementById('walletBalance'),
  nodeInfo: document.getElementById('nodeInfo'),
  transactionList: document.getElementById('transactionList'),
  qrCode: document.getElementById('qrCode'),
  fullAddress: document.getElementById('fullAddress'),
  
  // Tabs
  sendTab: document.getElementById('sendTab'),
  receiveTab: document.getElementById('receiveTab'),
  historyTab: document.getElementById('historyTab'),
  sendContent: document.getElementById('sendContent'),
  receiveContent: document.getElementById('receiveContent'),
  historyContent: document.getElementById('historyContent'),
  
  // Forms
  recipient: document.getElementById('recipient'),
  amount: document.getElementById('amount'),
  txData: document.getElementById('txData'),
  privateKey: document.getElementById('privateKey'),
  
  // Buttons
  createWalletBtn: document.getElementById('createWalletBtn'),
  importWalletBtn: document.getElementById('importWalletBtn'),
  confirmImportBtn: document.getElementById('confirmImportBtn'),
  cancelImportBtn: document.getElementById('cancelImportBtn'),
  sendBtn: document.getElementById('sendBtn'),
  copyAddressBtn: document.getElementById('copyAddressBtn'),
  logoutBtn: document.getElementById('logoutBtn'),
  confirmTxBtn: document.getElementById('confirmTxBtn'),
  cancelTxBtn: document.getElementById('cancelTxBtn'),
  
  // Modals
  transactionModal: document.getElementById('transactionModal'),
  confirmRecipient: document.getElementById('confirmRecipient'),
  confirmAmount: document.getElementById('confirmAmount'),
  
  // Add settings button
  settingsBtn: document.getElementById('settingsBtn')
};

// Initialize the app
async function init() {
  try {
    // Check node status
    await checkNodeStatus();
    
    // Check if wallet exists
    const hasWallet = await wallet.loadWallet();
    if (hasWallet) {
      showWalletScreen();
    } else {
      showLoginScreen();
    }
    
    // Start periodic status updates
    setInterval(checkNodeStatus, 10000);
    
    // Setup auto-logout
    setupAutoLogout();
  } catch (error) {
    console.error('Initialization error:', error);
    elements.networkStatus.textContent = 'Offline';
    elements.networkStatus.classList.add('error');
  }
}

// Check node status
async function checkNodeStatus() {
  try {
    nodeStatus = await wallet.api.getStatus();
    elements.networkStatus.textContent = 'Online';
    elements.networkStatus.classList.remove('error');
    elements.nodeInfo.textContent = `Node ID: ${nodeStatus.node_id.substring(0, 8)}...`;
    
    // If wallet is loaded, update balance and transactions
    if (wallet.address) {
      updateWalletInfo();
    }
  } catch (error) {
    console.error('Network status error:', error);
    elements.networkStatus.textContent = 'Offline';
    elements.networkStatus.classList.add('error');
  }
}

// Update wallet info (balance and transactions)
async function updateWalletInfo() {
  try {
    // Update balance
    await wallet.getBalance();
    elements.walletBalance.textContent = `${wallet.balance.toFixed(2)} OMB`;
    
    // Update address display
    elements.walletAddress.textContent = `Address: ${wallet.address.substring(0, 16)}...`;
    elements.fullAddress.textContent = wallet.address;
    
    // Generate QR code
    generateQRCode(wallet.address);
    
    // Update transaction history
    updateTransactionHistory();
  } catch (error) {
    console.error('Failed to update wallet info:', error);
  }
}

// Update transaction history
async function updateTransactionHistory() {
  try {
    await wallet.getTransactions();
    
    if (wallet.transactions.length === 0) {
      elements.transactionList.innerHTML = '<div class="loading">No transactions found</div>';
      return;
    }
    
    let html = '';
    wallet.transactions.sort((a, b) => b.timestamp - a.timestamp); // Sort by newest first
    
    for (const tx of wallet.transactions) {
      const isReceived = tx.recipient === wallet.address;
      const date = new Date(tx.timestamp * 1000).toLocaleDateString();
      const type = isReceived ? 'Received' : 'Sent';
      const typeClass = isReceived ? 'received' : 'sent';
      const amountDisplay = isReceived ? `+${tx.amount}` : `-${tx.amount}`;
      
      html += `
        <div class="transaction" data-hash="${tx.hash}">
          <div>
            <div class="tx-type ${typeClass}">${type}</div>
            <div class="tx-date">${date}</div>
          </div>
          <div class="tx-amount">${amountDisplay} OMB</div>
        </div>
      `;
    }
    
    elements.transactionList.innerHTML = html;
    
    // Add click event to transactions
    const txElements = document.querySelectorAll('.transaction');
    txElements.forEach(el => {
      el.addEventListener('click', () => {
        const txHash = el.getAttribute('data-hash');
        // Open transaction in blockchain explorer (could be added later)
        // For now just log it
        console.log('Transaction clicked:', txHash);
      });
    });
  } catch (error) {
    console.error('Failed to update transaction history:', error);
    elements.transactionList.innerHTML = '<div class="loading">Error loading transactions</div>';
  }
}

// Generate QR code for the address
function generateQRCode(address) {
  elements.qrCode.innerHTML = '';
  new QRCode(elements.qrCode, {
    text: address,
    width: 128,
    height: 128,
    colorDark: '#333b6a',
    colorLight: '#ffffff',
    correctLevel: QRCode.CorrectLevel.H
  });
}

// Show the login screen
function showLoginScreen() {
  screens.login.classList.remove('hidden');
  screens.import.classList.add('hidden');
  screens.wallet.classList.add('hidden');
}

// Show the import screen
function showImportScreen() {
  screens.login.classList.add('hidden');
  screens.import.classList.remove('hidden');
  screens.wallet.classList.add('hidden');
}

// Show the wallet screen
function showWalletScreen() {
  screens.login.classList.add('hidden');
  screens.import.classList.add('hidden');
  screens.wallet.classList.remove('hidden');
  updateWalletInfo();
}

// Switch between tabs
function showTab(tabId) {
  // Hide all tab content
  elements.sendContent.classList.add('hidden');
  elements.receiveContent.classList.add('hidden');
  elements.historyContent.classList.add('hidden');
  
  // Remove active class from all tabs
  elements.sendTab.classList.remove('active');
  elements.receiveTab.classList.remove('active');
  elements.historyTab.classList.remove('active');
  
  // Show the selected tab
  if (tabId === 'send') {
    elements.sendContent.classList.remove('hidden');
    elements.sendTab.classList.add('active');
  } else if (tabId === 'receive') {
    elements.receiveContent.classList.remove('hidden');
    elements.receiveTab.classList.add('active');
  } else if (tabId === 'history') {
    elements.historyContent.classList.remove('hidden');
    elements.historyTab.classList.add('active');
  }
}

// Show transaction confirmation modal
function showTransactionModal(recipient, amount) {
  elements.confirmRecipient.textContent = recipient.substring(0, 16) + '...';
  elements.confirmAmount.textContent = `${amount} OMB`;
  elements.transactionModal.classList.remove('hidden');
}

// Hide transaction confirmation modal
function hideTransactionModal() {
  elements.transactionModal.classList.add('hidden');
}

// Open settings page
elements.settingsBtn.addEventListener('click', () => {
  chrome.runtime.openOptionsPage ? 
    chrome.runtime.openOptionsPage() : 
    window.open(chrome.runtime.getURL('settings.html'));
});

// Add auto-logout functionality
let logoutTimer;
function setupAutoLogout() {
  clearTimeout(logoutTimer);
  
  chrome.storage.local.get(['ombraSecuritySettings'], (result) => {
    const settings = result.ombraSecuritySettings || {};
    const autoLogoutMins = settings.autoLogoutMins || 0;
    
    if (autoLogoutMins > 0) {
      logoutTimer = setTimeout(async () => {
        if (confirm('Your session is about to expire due to inactivity. Log out now?')) {
          await wallet.clearWallet();
          showLoginScreen();
        } else {
          setupAutoLogout(); // Reset timer if user cancels
        }
      }, autoLogoutMins * 60 * 1000);
    }
  });
}

// Reset logout timer on user activity
function resetLogoutTimer() {
  setupAutoLogout();
}

// Add event listeners for user activity
document.addEventListener('click', resetLogoutTimer);
document.addEventListener('keypress', resetLogoutTimer);

// Event Listeners
document.addEventListener('DOMContentLoaded', init);

// Create wallet
elements.createWalletBtn.addEventListener('click', async () => {
  try {
    await wallet.createWallet();
    showWalletScreen();
  } catch (error) {
    console.error('Failed to create wallet:', error);
    alert('Failed to create wallet: ' + error.message);
  }
});

// Show import screen
elements.importWalletBtn.addEventListener('click', () => {
  showImportScreen();
});

// Import wallet
elements.confirmImportBtn.addEventListener('click', async () => {
  const privateKey = elements.privateKey.value.trim();
  if (!privateKey) {
    alert('Please enter a private key');
    return;
  }
  
  try {
    await wallet.importWallet(privateKey);
    showWalletScreen();
  } catch (error) {
    console.error('Failed to import wallet:', error);
    alert('Failed to import wallet: ' + error.message);
  }
});

// Cancel import
elements.cancelImportBtn.addEventListener('click', () => {
  elements.privateKey.value = '';
  showLoginScreen();
});

// Tab switching
elements.sendTab.addEventListener('click', () => showTab('send'));
elements.receiveTab.addEventListener('click', () => showTab('receive'));
elements.historyTab.addEventListener('click', () => showTab('history'));

// Copy address
elements.copyAddressBtn.addEventListener('click', () => {
  const address = elements.fullAddress.textContent;
  navigator.clipboard.writeText(address)
    .then(() => {
      elements.copyAddressBtn.textContent = 'Copied!';
      setTimeout(() => {
        elements.copyAddressBtn.textContent = 'Copy Address';
      }, 2000);
    })
    .catch(err => {
      console.error('Could not copy address:', err);
    });
});

// Send transaction
elements.sendBtn.addEventListener('click', () => {
  const recipient = elements.recipient.value.trim();
  const amount = parseFloat(elements.amount.value);
  const data = elements.txData.value.trim();
  
  if (!recipient) {
    alert('Please enter a recipient address');
    return;
  }
  
  if (isNaN(amount) || amount <= 0) {
    alert('Please enter a valid amount');
    return;
  }
  
  showTransactionModal(recipient, amount);
});

// Confirm transaction
elements.confirmTxBtn.addEventListener('click', async () => {
  const recipient = elements.recipient.value.trim();
  const amount = parseFloat(elements.amount.value);
  const data = elements.txData.value.trim();
  
  hideTransactionModal();
  
  try {
    const result = await wallet.sendTransaction(recipient, amount, data);
    alert('Transaction sent successfully!');
    
    // Clear form
    elements.recipient.value = '';
    elements.amount.value = '';
    elements.txData.value = '';
    
    // Update wallet info
    updateWalletInfo();
  } catch (error) {
    console.error('Failed to send transaction:', error);
    alert('Failed to send transaction: ' + error.message);
  }
});

// Cancel transaction
elements.cancelTxBtn.addEventListener('click', () => {
  hideTransactionModal();
});

// Logout
elements.logoutBtn.addEventListener('click', async () => {
  if (confirm('Are you sure you want to log out? Make sure you have backed up your private key.')) {
    await wallet.clearWallet();
    showLoginScreen();
  }
});
