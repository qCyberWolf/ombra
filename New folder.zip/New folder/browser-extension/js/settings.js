import api from './api.js';
import UIComponents from './components.js';

// DOM elements
const elements = {
  apiEndpoint: document.getElementById('apiEndpoint'),
  autoLogout: document.getElementById('autoLogout'),
  saveApiBtn: document.getElementById('saveApiBtn'),
  testApiBtn: document.getElementById('testApiBtn'),
  saveSecurityBtn: document.getElementById('saveSecurityBtn'),
  backToWalletBtn: document.getElementById('backToWalletBtn'),
  apiStatus: document.getElementById('apiStatus'),
  nodeInfo: document.getElementById('nodeInfo')
};

// Load current settings
async function loadSettings() {
  try {
    UIComponents.showLoading('#apiEndpoint', 'Loading settings...');
    
    // Initialize API
    await api.initialize();
    elements.apiEndpoint.value = api.baseUrl;
    UIComponents.hideLoading('#apiEndpoint');
    
    // Display node info if connected
    if (api.nodeId) {
      elements.nodeInfo.textContent = `Connected to node: ${UIComponents.formatAddress(api.nodeId, 8, 8)}`;
      elements.nodeInfo.classList.add('connected');
    } else {
      elements.nodeInfo.textContent = 'Not connected to any node';
      elements.nodeInfo.classList.remove('connected');
    }
    
    // Load security settings
    const result = await chrome.storage.local.get(['ombraSecuritySettings']);
    const securitySettings = result.ombraSecuritySettings || {};
    elements.autoLogout.value = securitySettings.autoLogoutMins || 15;
    
  } catch (error) {
    console.error('Failed to load settings:', error);
    UIComponents.hideLoading('#apiEndpoint');
    UIComponents.showToast(`Failed to load settings: ${error.message}`, 'error');
  }
}

// Save API settings
async function saveApiSettings() {
  try {
    const endpoint = elements.apiEndpoint.value.trim();
    if (!endpoint) {
      UIComponents.showToast('Please enter a valid API endpoint', 'error');
      return;
    }
    
    UIComponents.showLoading('#saveApiBtn', 'Saving...');
    await api.setApiEndpoint(endpoint);
    UIComponents.hideLoading('#saveApiBtn');
    UIComponents.showToast('API settings saved successfully!', 'success');
    
    // Update node info if connected
    if (api.nodeId) {
      elements.nodeInfo.textContent = `Connected to node: ${UIComponents.formatAddress(api.nodeId, 8, 8)}`;
      elements.nodeInfo.classList.add('connected');
    }
  } catch (error) {
    UIComponents.hideLoading('#saveApiBtn');
    UIComponents.showToast(`Failed to save settings: ${error.message}`, 'error');
  }
}

// Test API connection
async function testApiConnection() {
  try {
    const endpoint = elements.apiEndpoint.value.trim();
    if (!endpoint) {
      UIComponents.showToast('Please enter API endpoint to test', 'warning');
      return;
    }
    
    UIComponents.showLoading('#testApiBtn', 'Testing...');
    
    // Create temporary API instance for testing
    const tempApi = new api.constructor();
    await tempApi.setApiEndpoint(endpoint);
    const status = await tempApi.getStatus();
    
    UIComponents.hideLoading('#testApiBtn');
    UIComponents.showToast(`Connection successful! Connected to node ID: ${UIComponents.formatAddress(status.node_id, 8, 8)}`, 'success');
  } catch (error) {
    UIComponents.hideLoading('#testApiBtn');
    UIComponents.showToast(`Connection failed: ${error.message}`, 'error');
  }
}

// Save security settings
async function saveSecuritySettings() {
  try {
    const autoLogoutMins = parseInt(elements.autoLogout.value) || 0;
    
    UIComponents.showLoading('#saveSecurityBtn', 'Saving...');
    
    const securitySettings = { autoLogoutMins: autoLogoutMins };
    await chrome.storage.local.set({ 'ombraSecuritySettings': securitySettings });
    
    UIComponents.hideLoading('#saveSecurityBtn');
    UIComponents.showToast('Security settings saved successfully!', 'success');
  } catch (error) {
    UIComponents.hideLoading('#saveSecurityBtn');
    UIComponents.showToast(`Failed to save security settings: ${error.message}`, 'error');
  }
}

// Event listeners
document.addEventListener('DOMContentLoaded', loadSettings);
elements.saveApiBtn.addEventListener('click', saveApiSettings);
elements.testApiBtn.addEventListener('click', testApiConnection);
elements.saveSecurityBtn.addEventListener('click', saveSecuritySettings);
elements.backToWalletBtn.addEventListener('click', () => {
  window.location.href = 'popup.html';
});
