import api from './api.js';

/**
 * Enhanced wallet management class
 */
class OmbraWallet {
  constructor() {
    this.address = null;
    this.publicKey = null;
    this.balance = 0;
    this.transactions = [];
    this.lastUpdated = null;
    this.initialized = false;
  }

  /**
   * Initialize wallet
   */
  async initialize() {
    const hasWallet = await this.loadWallet();
    this.initialized = true;
    return hasWallet;
  }

  /**
   * Create a new wallet
   */
  async createWallet() {
    try {
      const wallet = await api.createWallet();
      
      this.address = wallet.address;
      this.publicKey = wallet.public_key;
      this.balance = 0;
      this.transactions = [];
      this.lastUpdated = Date.now();
      
      await this.saveWallet();
      
      return {
        success: true,
        address: this.address
      };
    } catch (error) {
      console.error('Failed to create wallet:', error);
      throw error;
    }
  }

  /**
   * Import a wallet using a private key
   */
  async importWallet(privateKey) {
    try {
      const wallet = await api.importWallet(privateKey);
      
      this.address = wallet.address;
      this.publicKey = wallet.public_key;
      this.balance = 0;
      this.transactions = [];
      this.lastUpdated = Date.now();
      
      await this.saveWallet();
      
      return {
        success: true,
        address: this.address
      };
    } catch (error) {
      console.error('Failed to import wallet:', error);
      throw error;
    }
  }

  /**
   * Save wallet to browser storage
   */
  async saveWallet() {
    try {
      await chrome.storage.local.set({
        ombraWallet: {
          address: this.address,
          publicKey: this.publicKey,
          lastUpdated: this.lastUpdated
        }
      });
      
      return true;
    } catch (error) {
      console.error('Failed to save wallet:', error);
      throw error;
    }
  }

  /**
   * Load wallet from browser storage
   */
  async loadWallet() {
    try {
      const result = await chrome.storage.local.get(['ombraWallet']);
      
      if (result.ombraWallet) {
        this.address = result.ombraWallet.address;
        this.publicKey = result.ombraWallet.publicKey;
        this.lastUpdated = result.ombraWallet.lastUpdated;
        
        // Don't load balance and transactions here - they'll be fetched on demand
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Failed to load wallet:', error);
      return false;
    }
  }

  /**
   * Clear wallet data
   */
  async clearWallet() {
    try {
      await chrome.storage.local.remove('ombraWallet');
      
      this.address = null;
      this.publicKey = null;
      this.balance = 0;
      this.transactions = [];
      this.lastUpdated = null;
      
      return true;
    } catch (error) {
      console.error('Failed to clear wallet:', error);
      throw error;
    }
  }

  /**
   * Get wallet balance with refresh option
   */
  async getBalance(forceRefresh = false) {
    if (!this.address) {
      throw new Error('No wallet loaded');
    }
    
    try {
      if (forceRefresh || this.balance === 0) {
        const response = await api.getBalance(this.address);
        this.balance = response.balance;
      }
      
      return this.balance;
    } catch (error) {
      console.error('Failed to get balance:', error);
      throw error;
    }
  }

  /**
   * Get wallet transactions with refresh option
   */
  async getTransactions(forceRefresh = false) {
    if (!this.address) {
      throw new Error('No wallet loaded');
    }
    
    try {
      if (forceRefresh || this.transactions.length === 0) {
        const response = await api.getTransactions(this.address);
        this.transactions = response.transactions || [];
        
        // Sort transactions by timestamp (newest first)
        this.transactions.sort((a, b) => b.timestamp - a.timestamp);
      }
      
      return this.transactions;
    } catch (error) {
      console.error('Failed to get transactions:', error);
      throw error;
    }
  }

  /**
   * Send a transaction
   */
  async sendTransaction(recipient, amount, data = '') {
    if (!this.address) {
      throw new Error('No wallet loaded');
    }
    
    try {
      // Validate inputs
      if (!recipient || recipient.length < 10) {
        throw new Error('Invalid recipient address');
      }
      
      if (!amount || amount <= 0) {
        throw new Error('Amount must be greater than 0');
      }
      
      const response = await api.sendTransaction(
        this.address,
        recipient,
        parseFloat(amount),
        data
      );
      
      // Force refresh balance and transactions after sending
      setTimeout(() => {
        this.getBalance(true);
        this.getTransactions(true);
      }, 1000);
      
      return {
        success: true,
        txHash: response.transaction,
        message: response.message
      };
    } catch (error) {
      console.error('Failed to send transaction:', error);
      throw error;
    }
  }
  
  /**
   * Check if wallet exists in storage
   */
  static async exists() {
    try {
      const result = await chrome.storage.local.get(['ombraWallet']);
      return !!result.ombraWallet;
    } catch (error) {
      return false;
    }
  }
}

// Create and export a singleton instance
const wallet = new OmbraWallet();
export default wallet;
