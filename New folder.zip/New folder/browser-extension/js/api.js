/**
 * Enhanced API service for Ombra blockchain communication
 */
class OmbraAPI {
  constructor() {
    this.baseUrl = null;
    this.networkStatus = 'unknown';
    this.nodeId = null;
    this.connectionTimeout = 15000; // Increased to 15 seconds
    this.retryDelay = 1000;
    this.maxRetries = 3;
  }
  
  /**
   * Initialize the API service
   */
  async initialize() {
    await this.loadApiEndpoint();
    return this.checkConnection();
  }
  
  /**
   * Load API endpoint from storage
   */
  async loadApiEndpoint() {
    try {
      const result = await chrome.storage.local.get(['ombraApiEndpoint']);
      
      // Default to your public IP instead of localhost
      const defaultApiEndpoint = 'http://82.122.88.187:5000/api';
      
      // Don't use 0.0.0.0 as it's not a valid connection address
      if (result.ombraApiEndpoint && result.ombraApiEndpoint.includes('0.0.0.0')) {
        // Replace with specific IP for better compatibility
        this.baseUrl = result.ombraApiEndpoint.replace('0.0.0.0', '82.122.88.187');
        console.warn('Changed API endpoint from 0.0.0.0 to 82.122.88.187 for better compatibility');
      } else {
        this.baseUrl = result.ombraApiEndpoint || defaultApiEndpoint;
      }
      
      return this.baseUrl;
    } catch (error) {
      this.baseUrl = 'http://82.122.88.187:5000/api';
      console.error('Failed to load API endpoint:', error);
      return this.baseUrl;
    }
  }
  
  /**
   * Set a new API endpoint
   */
  async setApiEndpoint(endpoint) {
    if (!endpoint.endsWith('/api')) {
      endpoint = endpoint.endsWith('/') ? endpoint + 'api' : endpoint + '/api';
    }
    
    this.baseUrl = endpoint;
    
    try {
      await chrome.storage.local.set({ 'ombraApiEndpoint': endpoint });
      // Test the new connection
      return await this.checkConnection();
    } catch (error) {
      console.error('Failed to save API endpoint:', error);
      throw new Error(`Failed to save API endpoint: ${error.message}`);
    }
  }

  /**
   * Check connection to API
   */
  async checkConnection() {
    try {
      // Start with the fastest endpoint - health check
      const healthEndpoint = this.baseUrl.replace('/api', '/health');
      
      try {
        const healthResponse = await fetch(healthEndpoint, {
          signal: AbortSignal.timeout(3000) // 3 second timeout for health check
        });
        
        if (!healthResponse.ok) {
          // Try root endpoint as fallback
          const rootResponse = await fetch(this.baseUrl.replace('/api', '/'), {
            signal: AbortSignal.timeout(3000)
          });
          
          if (!rootResponse.ok) {
            throw new Error('Health check failed');
          }
        }
      } catch (healthError) {
        console.warn('Health check failed, trying status endpoint anyway', healthError);
      }
      
      // Use fast-status endpoint instead of regular status
      const response = await this.getFastStatus();
      
      this.networkStatus = 'online';
      this.nodeId = response.node_id;
      return { status: 'online', nodeId: this.nodeId, stats: response };
    } catch (error) {
      this.networkStatus = 'offline';
      this.nodeId = null;
      throw error;
    }
  }

  // Add new methods for different status endpoints
  async getFastStatus() {
    return this.request('/fast-status', 'GET', null, { 
      timeout: 3000  // Short timeout
    });
  }

  async getStatus() {
    try {
      // Try fast-status first
      return await this.getFastStatus();
    } catch (error) {
      // Fall back to regular status if fast endpoint fails
      console.log('Fast status failed, trying regular status endpoint');
      return this.request('/status', 'GET', null, {
        timeout: 15000 // Longer timeout for full status
      });
    }
  }

  /**
   * Make a request to the API with error handling, timeouts and retries
   */
  async request(endpoint, method = 'GET', body = null, options = {}) {
    if (!this.baseUrl) {
      await this.loadApiEndpoint();
    }
    
    let attempts = 0;
    let lastError = null;

    while (attempts < this.maxRetries) {
      try {
        attempts++;
        
        // Calculate timeout based on endpoint and method
        let timeout = options.timeout || this.connectionTimeout;
        if (endpoint === '/status' && !options.timeout) timeout = 5000;
        if (endpoint === '/fast-status' && !options.timeout) timeout = 3000;
        else if (method === 'POST' && !options.timeout) timeout = 30000;
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);
        
        const requestOptions = {
          method,
          headers: {
            'Content-Type': 'application/json',
          },
          signal: controller.signal,
          ...options
        };

        if (body) {
          requestOptions.body = JSON.stringify(body);
        }

        console.log(`API request attempt ${attempts}/${this.maxRetries}: ${method} ${endpoint}`);
        const response = await fetch(`${this.baseUrl}${endpoint}`, requestOptions);
        clearTimeout(timeoutId);
        
        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error || `API error (${response.status}): ${response.statusText}`);
        }

        return data;
      } catch (error) {
        lastError = error;
        
        // Check if we should retry
        const isTimeout = error.name === 'AbortError' || error.name === 'TimeoutError';
        const isNetworkError = error.message.includes('NetworkError') || 
                              error.message.includes('Failed to fetch');
        
        if ((isTimeout || isNetworkError) && attempts < this.maxRetries) {
          console.warn(`API request timed out or network error, retrying (${attempts}/${this.maxRetries})...`);
          // Wait before retrying with exponential backoff
          await new Promise(resolve => setTimeout(resolve, this.retryDelay * attempts));
          continue;
        }
        
        if (isTimeout) {
          throw new Error(`API request timed out after ${attempts} attempts. The server might be overloaded.`);
        } else {
          console.error(`API Error (${endpoint}):`, error);
          throw error;
        }
      }
    }
    
    throw lastError;
  }

  // API methods with enhanced error handling
  
  async createWallet() {
    return this.request('/wallet/create', 'POST');
  }

  async importWallet(privateKey) {
    return this.request('/wallet/import', 'POST', { private_key: privateKey });
  }

  async getBalance(address) {
    return this.request(`/wallet/${address}/balance`);
  }

  /**
   * Get wallet transactions with pagination
   */
  async getTransactions(address, page = 1, limit = 20) {
    return this.request(`/wallet/${address}/transactions?page=${page}&limit=${limit}`);
  }

  async sendTransaction(sender, recipient, amount, data = '') {
    return this.request('/transaction/send', 'POST', {
      sender,
      recipient,
      amount,
      data
    });
  }

  async getTransaction(txHash) {
    return this.request(`/transaction/${txHash}`);
  }
}

// Create and export a singleton instance
const api = new OmbraAPI();
export default api;
