/**
 * UI component system for Ombra wallet
 */
class UIComponents {
  /**
   * Show a notification toast
   */
  static showToast(message, type = 'info', duration = 3000) {
    // Remove existing toast if present
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
      existingToast.remove();
    }
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    // Add to body
    document.body.appendChild(toast);
    
    // Show with animation
    setTimeout(() => toast.classList.add('show'), 10);
    
    // Auto-hide after duration
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }
  
  /**
   * Show loading spinner
   */
  static showLoading(elementOrSelector, message = 'Loading...') {
    const container = typeof elementOrSelector === 'string' ?
      document.querySelector(elementOrSelector) :
      elementOrSelector;
      
    if (!container) return;
    
    // Save original content
    container.dataset.originalContent = container.innerHTML;
    
    // Set loading content
    container.innerHTML = `
      <div class="loading-container">
        <div class="loading-spinner"></div>
        <div class="loading-text">${message}</div>
      </div>
    `;
    
    // Add loading class
    container.classList.add('is-loading');
  }
  
  /**
   * Hide loading spinner and restore content
   */
  static hideLoading(elementOrSelector) {
    const container = typeof elementOrSelector === 'string' ?
      document.querySelector(elementOrSelector) :
      elementOrSelector;
      
    if (!container) return;
    
    // Remove loading class
    container.classList.remove('is-loading');
    
    // Restore original content if saved
    if (container.dataset.originalContent) {
      container.innerHTML = container.dataset.originalContent;
      delete container.dataset.originalContent;
    }
  }
  
  /**
   * Create a modal dialog
   */
  static createModal(options = {}) {
    const {
      title = '',
      content = '',
      buttons = [],
      closeOnOverlayClick = true,
      closeOnEscape = true,
      onClose = null
    } = options;
    
    // Create modal elements
    const modal = document.createElement('div');
    modal.className = 'modal';
    
    modal.innerHTML = `
      <div class="modal-overlay"></div>
      <div class="modal-container">
        <div class="modal-header">
          <h3>${title}</h3>
          <button class="modal-close-btn">&times;</button>
        </div>
        <div class="modal-content">${content}</div>
        <div class="modal-footer"></div>
      </div>
    `;
    
    // Add buttons
    const footer = modal.querySelector('.modal-footer');
    buttons.forEach(btn => {
      const button = document.createElement('button');
      button.textContent = btn.text;
      button.className = `button ${btn.type || 'secondary-button'}`;
      button.addEventListener('click', () => {
        btn.onClick();
        if (btn.closeModal !== false) {
          this.closeModal(modal);
        }
      });
      footer.appendChild(button);
    });
    
    // Handle close button
    const closeBtn = modal.querySelector('.modal-close-btn');
    closeBtn.addEventListener('click', () => this.closeModal(modal, onClose));
    
    // Handle overlay click
    if (closeOnOverlayClick) {
      const overlay = modal.querySelector('.modal-overlay');
      overlay.addEventListener('click', () => this.closeModal(modal, onClose));
    }
    
    // Handle escape key
    if (closeOnEscape) {
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && document.body.contains(modal)) {
          this.closeModal(modal, onClose);
        }
      });
    }
    
    // Add to DOM
    document.body.appendChild(modal);
    
    // Show with animation
    setTimeout(() => modal.classList.add('show'), 10);
    
    return modal;
  }
  
  /**
   * Close a modal dialog
   */
  static closeModal(modal, onClose = null) {
    modal.classList.remove('show');
    setTimeout(() => {
      modal.remove();
      if (onClose) onClose();
    }, 300);
  }
  
  /**
   * Show transaction confirmation modal
   */
  static showTransactionConfirmation(transaction, onConfirm, onCancel) {
    const { recipient, amount, data = '' } = transaction;
    
    const shortenedRecipient = recipient.substring(0, 12) + '...' + recipient.substring(recipient.length - 8);
    
    const content = `
      <div class="tx-confirmation">
        <div class="tx-field">
          <div class="tx-label">Recipient:</div>
          <div class="tx-value" title="${recipient}">${shortenedRecipient}</div>
        </div>
        <div class="tx-field">
          <div class="tx-label">Amount:</div>
          <div class="tx-value tx-amount">${amount} OMB</div>
        </div>
        ${data ? `
          <div class="tx-field">
            <div class="tx-label">Message:</div>
            <div class="tx-value tx-data">${data}</div>
          </div>
        ` : ''}
        <div class="tx-warning">
          <p>📝 Transactions cannot be reversed once confirmed!</p>
        </div>
      </div>
    `;
    
    return this.createModal({
      title: 'Confirm Transaction',
      content,
      buttons: [
        {
          text: 'Cancel',
          type: 'secondary-button',
          onClick: onCancel
        },
        {
          text: 'Send Transaction',
          type: 'primary-button',
          onClick: onConfirm
        }
      ],
      closeOnOverlayClick: false
    });
  }
  
  /**
   * Create a QR code
   */
  static createQRCode(selector, data, options = {}) {
    const element = document.querySelector(selector);
    if (!element) return;
    
    // Clear element
    element.innerHTML = '';
    
    // Generate QR code
    new QRCode(element, {
      text: data,
      width: options.width || 180,
      height: options.height || 180,
      colorDark: options.colorDark || '#333b6a',
      colorLight: options.colorLight || '#ffffff',
      correctLevel: QRCode.CorrectLevel.H
    });
  }
  
  /**
   * Format address for display
   */
  static formatAddress(address, prefixLength = 8, suffixLength = 4) {
    if (!address || address.length < (prefixLength + suffixLength + 3)) {
      return address;
    }
    
    const prefix = address.substring(0, prefixLength);
    const suffix = address.substring(address.length - suffixLength);
    return `${prefix}...${suffix}`;
  }
  
  /**
   * Format date for display
   */
  static formatDate(timestamp) {
    const date = new Date(timestamp * 1000);
    return date.toLocaleString();
  }
  
  /**
   * Format currency amount
   */
  static formatAmount(amount) {
    return parseFloat(amount).toFixed(2);
  }
}

export default UIComponents;
