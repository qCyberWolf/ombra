import api from './js/api.js';

/**
 * Background service worker for the Ombra Wallet extension
 */

// Listen for extension installation
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Ombra Wallet extension installed');
    // Show onboarding on first install
    chrome.tabs.create({ url: 'onboarding.html' });
  } else if (details.reason === 'update') {
    console.log('Ombra Wallet extension updated');
  }
});

// Check API connection periodically
async function checkApiConnection() {
  try {
    // Use the API class for consistency
    await api.loadApiEndpoint();
    const status = await api.getStatus();
    
    // Update badge if API is connected
    chrome.action.setBadgeText({ text: 'ON' });
    chrome.action.setBadgeBackgroundColor({ color: '#4CD964' });
    
    // Store connection state
    chrome.storage.local.set({ 'ombraNetworkStatus': 'online' });
    
    return true;
  } catch (error) {
    // Update badge if API is disconnected
    chrome.action.setBadgeText({ text: 'OFF' });
    chrome.action.setBadgeBackgroundColor({ color: '#FF3B30' });
    
    // Store connection state
    chrome.storage.local.set({ 'ombraNetworkStatus': 'offline' });
    
    return false;
  }
}

// Check connection immediately and then every 30 seconds
checkApiConnection();
setInterval(checkApiConnection, 30000);
