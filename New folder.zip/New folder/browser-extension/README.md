# Ombra Blockchain Wallet Browser Extension

This browser extension allows users to interact with the Ombra blockchain directly from their browser.

## Setup Instructions

### Prerequisites

1. The Ombra blockchain API server must be running locally on port 5000
   - Run the API server using: `python api/api_server.py`

2. Create or download the required image files:
   - Create a folder: `images/`
   - Add the following images:
     - `logo.png` - Logo image for the wallet (128x128px recommended)
     - `icon16.png` - 16x16 icon
     - `icon48.png` - 48x48 icon
     - `icon128.png` - 128x128 icon

3. Download QR Code library:
   - Download the QRCode.js library from: https://github.com/davidshimjs/qrcodejs
   - Save the minified version as `js/qrcode.min.js`

### Installing in Chrome/Edge

1. Open Chrome or Edge and navigate to: `chrome://extensions/`
2. Enable "Developer mode" (toggle in the top right)
3. Click "Load unpacked" and select the `browser-extension` folder
4. The extension should now appear in your browser toolbar

## Features

- Create and import wallets
- Send and receive OMB tokens
- View transaction history
- QR code for receiving funds
- Transaction security verification

## Connecting to Different Networks

By default, the extension connects to `http://localhost:5000`. To connect to a different API endpoint:

1. Open `js/api.js`
2. Change the base URL in the constructor:
```javascript
constructor(baseUrl = 'http://your-api-server.com/api') {
  this.baseUrl = baseUrl;
}
```

## Troubleshooting

- If the extension shows "Offline", check that the API server is running
- If transactions fail, check your wallet balance and connection status
- For import issues, ensure your private key format is correct

## Security Notes

- This extension stores your wallet data in the browser's local storage
- Always back up your private keys separately
- Never share your private keys with anyone
