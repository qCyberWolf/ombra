"""
Utility script to check if the Ombra API server is accessible
"""
import socket
import json
import urllib.request
import urllib.error
import sys
import time

def check_port_open(host, port, timeout=2):
    """Check if a port is open on a host"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except socket.error:
        return False

def check_api_health(url):
    """Check if the API health endpoint responds correctly"""
    try:
        with urllib.request.urlopen(url, timeout=5) as response:
            if response.status == 200:
                return json.loads(response.read().decode('utf-8'))
            else:
                return None
    except urllib.error.URLError:
        return None
    except json.JSONDecodeError:
        return None

def get_local_ips():
    """Get list of possible local IPs to try"""
    ips = ['localhost', '127.0.0.1']
    
    # Try to get local network IP
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        if local_ip != '127.0.0.1':
            ips.append(local_ip)
    except:
        pass
    
    # Try interface-based detection
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 1))
        local_ip = s.getsockname()[0]
        s.close()
        if local_ip not in ips:
            ips.append(local_ip)
    except:
        pass
    
    return ips

def main():
    """Check server accessibility"""
    port = 5000  # Default Ombra API port
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        port = int(sys.argv[1])
    
    print(f"Checking Ombra API server accessibility on port {port}...")
    print("-" * 60)
    
    # 1. First check if the port is even open
    local_ips = get_local_ips()
    accessible_hosts = []
    
    print("Testing connection to server...")
    for host in local_ips:
        sys.stdout.write(f"- Checking {host}:{port}... ")
        sys.stdout.flush()
        if check_port_open(host, port):
            accessible_hosts.append(host)
            print("✓ OPEN")
        else:
            print("✗ CLOSED/FILTERED")
    
    if not accessible_hosts:
        print("\n❌ ERROR: Could not connect to any server!")
        print("Possible reasons:")
        print("- The server is not running")
        print("- The server is running on a different port")
        print("- A firewall is blocking the connection")
        print("\nTry running: python api/production_server.py")
        return
    
    # 2. Check API health for each accessible host
    print("\nTesting API health...")
    working_endpoints = []
    
    for host in accessible_hosts:
        url = f"http://{host}:{port}/health"
        sys.stdout.write(f"- Checking API at {url}... ")
        sys.stdout.flush()
        
        result = check_api_health(url)
        if result:
            working_endpoints.append(host)
            print(f"✓ HEALTHY ({result.get('status', 'unknown')})")
        else:
            print("✗ NOT RESPONDING")
    
    if not working_endpoints:
        print("\n❌ ERROR: API server is not responding!")
        print("The port is open, but the API is not responding correctly.")
        return
    
    # 3. Final report
    print("\n✅ SUCCESS! The API server is accessible.")
    print("\nUse one of these URLs in your browser extension:")
    for host in working_endpoints:
        print(f"- http://{host}:{port}/api")
    
    # For 0.0.0.0, remind that you need to use actual IP
    if '0.0.0.0' in accessible_hosts:
        print("\nNote: Do not use '0.0.0.0' directly - use one of the other IPs instead.")

if __name__ == "__main__":
    main()
