# Ombra API Network Troubleshooting Guide

If you're having trouble connecting to your Ombra API server, follow this guide to identify and fix the issues.

## Local Connection Issues

### 1. Verify Server is Running

```bash
# Check if server is running
python verify_api_connection.py localhost
```

If the server isn't running locally, start it with:

```bash
# Start the server
python api/production_server.py
# or
start_public_api.bat
```

### 2. Check for Port Conflicts

If there's already a service running on port 5000, you'll need to use a different port:

```bash
# Start server on alternate port
python api/production_server.py --port 5001
```

Then update your browser extension to use the new port.

## Remote Connection Issues

### 1. Ensure Server is Binding to All Interfaces

Always use `0.0.0.0` as the host to bind to all network interfaces:

```bash
python api/production_server.py --host 0.0.0.0
```

### 2. Check Windows Firewall

Windows Firewall may be blocking incoming connections:

1. Run the server with automatic firewall configuration:
   ```bash
   python api/production_server.py --host 0.0.0.0 --auto-firewall
   